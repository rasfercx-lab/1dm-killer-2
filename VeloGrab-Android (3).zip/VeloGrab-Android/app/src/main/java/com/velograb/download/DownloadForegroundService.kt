package com.velograb.download

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.velograb.MainActivity
import com.velograb.R
import com.velograb.VeloGrabApp
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.domain.model.StreamType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class DownloadForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val pausedOrCancelledIds = ConcurrentHashMap.newKeySet<String>()
    private val downloadSemaphore = Semaphore(2)
    private var wakeLock: PowerManager.WakeLock? = null

    private val app: VeloGrabApp
        get() = application as VeloGrabApp

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            serviceScope.launch { checkIdleStop() }
            return START_NOT_STICKY
        }

        val action = intent.action
        val taskId = intent.getStringExtra(EXTRA_TASK_ID)

        when (action) {
            ACTION_START, ACTION_RESUME -> {
                if (!taskId.isNullOrBlank()) {
                    pausedOrCancelledIds.remove(taskId)
                    promoteToForeground("İndirme başlatılıyor...", 0, "")
                    launchDownloadJob(taskId)
                } else {
                    serviceScope.launch { checkIdleStop() }
                }
            }
            ACTION_RESUME_INTERRUPTED -> {
                promoteToForeground("Yarım kalan indirmeler sürdürülüyor...", 0, "")
                serviceScope.launch {
                    val interrupted = app.container.repository.getActiveTasks()
                    if (interrupted.isEmpty()) {
                        checkIdleStop()
                    } else {
                        interrupted.forEach { pending ->
                            if (!pausedOrCancelledIds.contains(pending.id)) {
                                launchDownloadJob(pending.id)
                            }
                        }
                    }
                }
            }
            ACTION_PAUSE -> {
                if (!taskId.isNullOrBlank()) {
                    pausedOrCancelledIds.add(taskId)
                    activeJobs[taskId]?.cancel()
                    serviceScope.launch {
                        app.container.repository.updateStatus(taskId, DownloadStatus.PAUSED)
                        checkIdleStop()
                    }
                }
            }
            ACTION_CANCEL -> {
                if (!taskId.isNullOrBlank()) {
                    pausedOrCancelledIds.add(taskId)
                    activeJobs[taskId]?.cancel()
                    serviceScope.launch {
                        app.container.repository.updateStatus(taskId, DownloadStatus.CANCELLED)
                        cleanupWorkDir(taskId)
                        checkIdleStop()
                    }
                }
            }
            else -> {
                serviceScope.launch { checkIdleStop() }
            }
        }
        return START_NOT_STICKY
    }

    private fun launchDownloadJob(taskId: String) {
        if (activeJobs[taskId]?.isActive == true) return
        acquireWakeLock()

        val job = serviceScope.launch {
            val repo = app.container.repository
            try {
                downloadSemaphore.withPermit {
                    if (pausedOrCancelledIds.contains(taskId)) return@withPermit
                    val task = repo.getTask(taskId) ?: return@withPermit
                    val workDir = File(cacheDir, "velograb_tasks/${task.id}").apply { mkdirs() }

                    try {
                        repo.updateStatus(task.id, DownloadStatus.DOWNLOADING)
                        val finalFile: File
                        val durationMs: Long

                when (task.streamType) {
                    StreamType.HLS_MASTER,
                    StreamType.HLS_MEDIA,
                    StreamType.HLS_AUDIO,
                    StreamType.DASH_MPD,
                    StreamType.DASH_AUDIO -> {
                        val segDownloader = SegmentedStreamDownloader(
                            context = applicationContext,
                            okHttpClient = app.container.okHttpClient,
                            repository = repo
                        )
                        val result = segDownloader.downloadAndMux(
                            task = task,
                            workDir = workDir,
                            isPausedOrCancelled = { pausedOrCancelledIds.contains(task.id) },
                            onProgress = { doneSegs, totalSegs, dlBytes, speedBps, etaSec ->
                                if (pausedOrCancelledIds.contains(task.id)) return@downloadAndMux
                                val pct = if (totalSegs > 0) (doneSegs.toFloat() / totalSegs) * 100f else 0f
                                val estTotal = if (doneSegs > 0) (dlBytes * totalSegs) / doneSegs else dlBytes
                                serviceScope.launch {
                                    if (!pausedOrCancelledIds.contains(task.id)) {
                                        repo.updateProgress(
                                            id = task.id,
                                            status = DownloadStatus.DOWNLOADING,
                                            progressPercent = pct,
                                            downloadedBytes = dlBytes,
                                            totalBytes = estTotal,
                                            speedBytesPerSec = speedBps,
                                            etaSeconds = etaSec,
                                            completedSegments = doneSegs,
                                            totalSegments = totalSegs
                                        )
                                    }
                                }
                                updateNotification(
                                    task = task,
                                    percent = pct.toInt(),
                                    speedText = formatSpeed(speedBps)
                                )
                            }
                        )
                        finalFile = result.finalMuxedFile
                        durationMs = result.durationMs
                    }

                    StreamType.DIRECT_MP4,
                    StreamType.DIRECT_WEBM,
                    StreamType.AUDIO_ONLY -> {
                        val rangeDownloader = MultiThreadRangeDownloader(
                            okHttpClient = app.container.okHttpClient,
                            repository = repo
                        )
                        val ext = when (task.streamType) {
                            StreamType.DIRECT_WEBM -> "webm"
                            StreamType.AUDIO_ONLY -> "m4a"
                            else -> "mp4"
                        }
                        val tempFile = File(workDir, "direct_media.$ext")
                        rangeDownloader.download(
                            task = task,
                            tempFile = tempFile,
                            isPausedOrCancelled = { pausedOrCancelledIds.contains(task.id) },
                            onSpeedSample = { dlBytes, totalBytes, speedBps, etaSec ->
                                if (pausedOrCancelledIds.contains(task.id)) return@download
                                val pct = if (totalBytes > 0) (dlBytes.toFloat() / totalBytes) * 100f else 0f
                                serviceScope.launch {
                                    if (!pausedOrCancelledIds.contains(task.id)) {
                                        repo.updateProgress(
                                            id = task.id,
                                            status = DownloadStatus.DOWNLOADING,
                                            progressPercent = pct,
                                            downloadedBytes = dlBytes,
                                            totalBytes = totalBytes,
                                            speedBytesPerSec = speedBps,
                                            etaSeconds = etaSec
                                        )
                                    }
                                }
                                updateNotification(
                                    task = task,
                                    percent = pct.toInt(),
                                    speedText = formatSpeed(speedBps)
                                )
                            }
                        )
                        finalFile = tempFile
                        durationMs = MediaMuxerEngine.extractDurationMs(tempFile)
                    }
                }

                        if (pausedOrCancelledIds.contains(task.id)) return@withPermit

                        val isAudio = task.streamType == StreamType.AUDIO_ONLY ||
                            task.streamType == StreamType.HLS_AUDIO ||
                            task.streamType == StreamType.DASH_AUDIO
                        val mime = when {
                            isAudio -> "audio/mp4"
                            task.streamType == StreamType.DIRECT_WEBM -> "video/webm"
                            else -> "video/mp4"
                        }

                        val publishedUri = MediaStorePublisher.publishToMoviesVeloGrab(
                            context = applicationContext,
                            sourceFile = finalFile,
                            displayName = task.title,
                            mimeType = mime,
                            isAudioOnly = isAudio
                        )

                        repo.markCompleted(
                            id = task.id,
                            outputUri = publishedUri.toString(),
                            finalBytes = finalFile.length(),
                            durationMs = durationMs
                        )
                        cleanupWorkDir(task.id)
                        showCompletedNotification(task, isAudio)
                    } catch (_: CancellationException) {
                        // Paused or cancelled cleanly; chunk/segment progress already persisted in Room
                    } catch (e: Exception) {
                        repo.updateStatus(
                            id = task.id,
                            status = DownloadStatus.FAILED,
                            errorMessage = e.localizedMessage ?: "Bilinmeyen ağ veya depolama hatası"
                        )
                    }
                }
            } finally {
                activeJobs.remove(taskId)
                checkIdleStop()
            }
        }

        activeJobs[taskId] = job
    }

    private fun promoteToForeground(title: String, percent: Int, speedText: String) {
        val notification = buildProgressNotification(null, title, percent, speedText)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID_PROGRESS,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID_PROGRESS, notification)
            }
        }
    }

    private fun updateNotification(task: DownloadTask, percent: Int, speedText: String) {
        val notification = buildProgressNotification(task.id, task.title, percent, speedText)
        runCatching {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID_PROGRESS, notification)
        }
    }

    private fun buildProgressNotification(
        taskId: String?,
        title: String,
        percent: Int,
        speedText: String
    ): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, VeloGrabApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(if (speedText.isNotBlank()) "%$percent • $speedText" else "%$percent")
            .setProgress(100, percent.coerceIn(0, 100), percent == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)

        if (!taskId.isNullOrBlank()) {
            val pauseIntent = PendingIntent.getService(
                this,
                taskId.hashCode(),
                Intent(this, DownloadForegroundService::class.java).apply {
                    action = ACTION_PAUSE
                    putExtra(EXTRA_TASK_ID, taskId)
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val cancelIntent = PendingIntent.getService(
                this,
                taskId.hashCode() + 1,
                Intent(this, DownloadForegroundService::class.java).apply {
                    action = ACTION_CANCEL
                    putExtra(EXTRA_TASK_ID, taskId)
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(0, getString(R.string.action_pause), pauseIntent)
            builder.addAction(0, getString(R.string.action_cancel), cancelIntent)
        }

        return builder.build()
    }

    private fun showCompletedNotification(task: DownloadTask, isAudio: Boolean) {
        val folderName = if (isAudio) "Music/VeloGrab" else "Movies/VeloGrab"
        val notification = NotificationCompat.Builder(this, VeloGrabApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("İndirme Tamamlandı")
            .setContentText("${task.title} $folderName klasörüne kaydedildi")
            .setAutoCancel(true)
            .build()
        runCatching {
            NotificationManagerCompat.from(this).notify(task.id.hashCode(), notification)
        }
    }

    private fun checkIdleStop() {
        if (activeJobs.values.none { it.isActive }) {
            releaseWakeLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cleanupWorkDir(taskId: String) {
        runCatching { File(cacheDir, "velograb_tasks/$taskId").deleteRecursively() }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VeloGrab::DownloadWakeLock").apply {
            acquire(60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
    }

    override fun onDestroy() {
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return ""
        val kb = bytesPerSec / 1024.0
        return if (kb >= 1024.0) {
            String.format(Locale("tr", "TR"), "%.1f MB/sn", kb / 1024.0)
        } else {
            String.format(Locale("tr", "TR"), "%.0f KB/sn", kb)
        }
    }

    companion object {
        const val ACTION_START = "com.velograb.action.START"
        const val ACTION_PAUSE = "com.velograb.action.PAUSE"
        const val ACTION_RESUME = "com.velograb.action.RESUME"
        const val ACTION_RESUME_INTERRUPTED = "com.velograb.action.RESUME_INTERRUPTED"
        const val ACTION_CANCEL = "com.velograb.action.CANCEL"
        const val EXTRA_TASK_ID = "extra_task_id"
        private const val NOTIFICATION_ID_PROGRESS = 1001

        fun sendCommand(context: Context, action: String, taskId: String) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                this.action = action
                putExtra(EXTRA_TASK_ID, taskId)
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        fun resumeInterruptedIfNeeded(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_RESUME_INTERRUPTED
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }
    }
}
