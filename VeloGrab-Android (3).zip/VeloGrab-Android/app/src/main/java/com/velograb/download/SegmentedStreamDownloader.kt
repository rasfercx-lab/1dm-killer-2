package com.velograb.download

import android.content.Context
import com.velograb.data.repository.DownloadRepository
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.domain.model.DrmStatus
import com.velograb.domain.model.HlsSegment
import com.velograb.domain.model.StreamType
import com.velograb.network.OkHttpClientProvider
import com.velograb.parser.Aes128Decryptor
import com.velograb.parser.DashMpdParser
import com.velograb.parser.DrmGuard
import com.velograb.parser.HlsPlaylistParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class SegmentedStreamDownloader(
    private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val repository: DownloadRepository
) {
    private val decryptor = Aes128Decryptor(okHttpClient)

    data class SegmentedOutput(
        val finalMuxedFile: File,
        val durationMs: Long
    )

    suspend fun downloadAndMux(
        task: DownloadTask,
        workDir: File,
        isPausedOrCancelled: () -> Boolean,
        onProgress: (
            completedSegments: Int,
            totalSegments: Int,
            downloadedBytes: Long,
            speedBps: Long,
            etaSec: Long
        ) -> Unit
    ): SegmentedOutput = withContext(Dispatchers.IO) {
        workDir.mkdirs()

        val videoSegments: List<HlsSegment>
        val audioSegments: List<HlsSegment>
        var videoInitUrl: String? = null
        var videoInitByteRange: String? = null
        var audioInitUrl: String? = null
        var audioInitByteRange: String? = null

        val isAudioOnlyTask = task.streamType == StreamType.HLS_AUDIO || task.streamType == StreamType.DASH_AUDIO

        when (task.streamType) {
            StreamType.DASH_MPD, StreamType.DASH_AUDIO -> {
                val mpdText = fetchTextWithRetry(task.videoUrl, task)
                val parsed = DashMpdParser.parseManifest(mpdText, task.videoUrl)
                if (parsed.drmStatus is DrmStatus.Protected) {
                    throw IllegalStateException(DrmGuard.DRM_MESSAGE_TR)
                }
                val selectedAudio = parsed.audioTracks.firstOrNull { it.id == task.audioUrl }
                    ?: parsed.audioTracks.maxByOrNull { it.bandwidthBps }

                if (task.streamType == StreamType.DASH_AUDIO) {
                    val audioTrack = selectedAudio ?: throw IllegalStateException("DASH ses akışı bulunamadı.")
                    videoSegments = emptyList()
                    audioInitUrl = audioTrack.initUrl
                    audioSegments = audioTrack.segmentUrls.mapIndexed { idx, url ->
                        HlsSegment(idx, url, 4.0)
                    }
                } else {
                    val selectedVideo = parsed.videoTracks.firstOrNull { task.qualityLabel.contains("${it.height}p") }
                        ?: parsed.videoTracks.maxByOrNull { it.height }
                        ?: throw IllegalStateException("DASH video akışı bulunamadı.")

                    videoInitUrl = selectedVideo.initUrl
                    audioInitUrl = selectedAudio?.initUrl
                    videoSegments = selectedVideo.segmentUrls.mapIndexed { idx, url ->
                        HlsSegment(idx, url, 4.0)
                    }
                    audioSegments = selectedAudio?.segmentUrls?.mapIndexed { idx, url ->
                        HlsSegment(idx, url, 4.0)
                    }.orEmpty()
                }
            }

            StreamType.HLS_AUDIO -> {
                val audioPlaylistText = fetchTextWithRetry(task.videoUrl, task)
                val audioPlaylist = HlsPlaylistParser.parseMediaPlaylist(audioPlaylistText, task.videoUrl)
                if (audioPlaylist.drmStatus is DrmStatus.Protected) {
                    throw IllegalStateException(DrmGuard.DRM_MESSAGE_TR)
                }
                videoSegments = emptyList()
                audioSegments = audioPlaylist.segments
                audioInitUrl = audioSegments.firstOrNull()?.initSegmentUrl
                audioInitByteRange = audioSegments.firstOrNull()?.initByteRange
            }

            else -> {
                val videoPlaylistText = fetchTextWithRetry(task.videoUrl, task)
                val videoPlaylist = HlsPlaylistParser.parseMediaPlaylist(videoPlaylistText, task.videoUrl)
                if (videoPlaylist.drmStatus is DrmStatus.Protected) {
                    throw IllegalStateException(DrmGuard.DRM_MESSAGE_TR)
                }
                videoSegments = videoPlaylist.segments
                videoInitUrl = videoSegments.firstOrNull()?.initSegmentUrl
                videoInitByteRange = videoSegments.firstOrNull()?.initByteRange

                audioSegments = if (!task.audioUrl.isNullOrBlank()) {
                    val audioPlaylistText = fetchTextWithRetry(task.audioUrl, task)
                    val audioPlaylist = HlsPlaylistParser.parseMediaPlaylist(audioPlaylistText, task.audioUrl)
                    if (audioPlaylist.drmStatus is DrmStatus.Protected) {
                        throw IllegalStateException(DrmGuard.DRM_MESSAGE_TR)
                    }
                    audioInitUrl = audioPlaylist.segments.firstOrNull()?.initSegmentUrl
                    audioInitByteRange = audioPlaylist.segments.firstOrNull()?.initByteRange
                    audioPlaylist.segments
                } else emptyList()
            }
        }

        val totalSegments = (videoSegments.size + audioSegments.size).coerceAtLeast(1)
        val completedVideoMap = repository.getCompletedSegments(task.id, "video")
        val completedAudioMap = repository.getCompletedSegments(task.id, "audio")

        val initialCompletedCount = completedVideoMap.size + completedAudioMap.size
        val initialBytes = completedVideoMap.values.sumOf { it.byteSize } +
            completedAudioMap.values.sumOf { it.byteSize }

        val completedCounter = AtomicInteger(initialCompletedCount)
        val downloadedBytesCounter = AtomicLong(initialBytes)
        val semaphore = Semaphore(4)

        val videoDir = File(workDir, "video").apply { mkdirs() }
        val audioDir = File(workDir, "audio").apply { mkdirs() }

        var lastWindowBytes = initialBytes
        var lastTickMillis = System.currentTimeMillis()
        val progressLock = Any()

        // Download optional fMP4 init segments first
        val videoInitFile = videoInitUrl?.let { url ->
            File(videoDir, "init.mp4").also { f ->
                if (!f.exists() || f.length() == 0L) {
                    f.writeBytes(fetchBytesWithRetry(url, task, buildRangeHeader(videoInitByteRange)))
                }
            }
        }
        val audioInitFile = audioInitUrl?.let { url ->
            File(audioDir, "init.mp4").also { f ->
                if (!f.exists() || f.length() == 0L) {
                    f.writeBytes(fetchBytesWithRetry(url, task, buildRangeHeader(audioInitByteRange)))
                }
            }
        }

        suspend fun downloadTrackSegments(
            trackKind: String,
            segments: List<HlsSegment>,
            dir: File,
            alreadyDone: Map<Int, com.velograb.data.local.SegmentStateEntity>
        ) = coroutineScope {
            val jobs = segments.map { seg ->
                async(Dispatchers.IO) {
                    val segFile = File(dir, "seg_${seg.index.toString().padStart(6, '0')}.part")
                    if (alreadyDone.containsKey(seg.index) && segFile.exists() && segFile.length() > 0L) {
                        return@async
                    }
                    semaphore.withPermit {
                        if (isPausedOrCancelled() || !isActive) throw CancellationException("Paused")
                        val rawBytes = fetchBytesWithRetry(seg.url, task, buildRangeHeader(seg.byteRange))
                        val plainBytes = decryptor.decryptIfNeeded(
                            bytes = rawBytes,
                            keyInfo = seg.keyInfo,
                            segmentSequenceIndex = seg.index,
                            headers = task.headers
                        )
                        segFile.writeBytes(plainBytes)
                        repository.markSegmentCompleted(task.id, trackKind, seg.index, plainBytes.size.toLong())

                        val done = completedCounter.incrementAndGet()
                        val totalDl = downloadedBytesCounter.addAndGet(plainBytes.size.toLong())
                        val now = System.currentTimeMillis()
                        synchronized(progressLock) {
                            val elapsed = now - lastTickMillis
                            if (elapsed >= 400L || done == totalSegments) {
                                val delta = totalDl - lastWindowBytes
                                lastWindowBytes = totalDl
                                val speedBps = (delta * 1000L) / elapsed.coerceAtLeast(1L)
                                val avgSegBytes = (totalDl / done.coerceAtLeast(1)).coerceAtLeast(1L)
                                val remainingBytes = (totalSegments - done) * avgSegBytes
                                val eta = if (speedBps > 0) remainingBytes / speedBps else 0L
                                lastTickMillis = now
                                onProgress(done, totalSegments, totalDl, speedBps, eta)
                            }
                        }
                    }
                }
            }
            jobs.awaitAll()
        }

        if (videoSegments.isNotEmpty()) {
            downloadTrackSegments("video", videoSegments, videoDir, completedVideoMap)
        }
        if (audioSegments.isNotEmpty()) {
            downloadTrackSegments("audio", audioSegments, audioDir, completedAudioMap)
        }

        if (isPausedOrCancelled()) throw CancellationException("Paused")

        val videoExt = if (videoInitFile != null) "mp4" else "ts"
        val concatenatedVideo = if (videoSegments.isNotEmpty()) {
            File(workDir, "video_raw.$videoExt").also { out ->
                concatFiles(videoInitFile, videoSegments.indices.map {
                    File(videoDir, "seg_${videoSegments[it].index.toString().padStart(6, '0')}.part")
                }, out)
            }
        } else null

        val audioExt = if (audioInitFile != null) "mp4" else "aac"
        val concatenatedAudio = if (audioSegments.isNotEmpty()) {
            File(workDir, "audio_raw.$audioExt").also { out ->
                concatFiles(audioInitFile, audioSegments.indices.map {
                    File(audioDir, "seg_${audioSegments[it].index.toString().padStart(6, '0')}.part")
                }, out)
            }
        } else null

        repository.updateStatus(task.id, DownloadStatus.MUXING)
        val outExt = if (isAudioOnlyTask) "m4a" else "mp4"
        val finalMuxed = File(workDir, "final_output.$outExt")
        val muxResult = MediaMuxerEngine.muxToMp4(
            context = context,
            videoInput = concatenatedVideo,
            audioInput = concatenatedAudio,
            outputFile = finalMuxed
        )

        SegmentedOutput(finalMuxedFile = muxResult.outputFile, durationMs = muxResult.durationMs)
    }

    private fun buildRangeHeader(byteRange: String?): String? {
        if (byteRange.isNullOrBlank()) return null
        val length = byteRange.substringBefore('@').toLongOrNull() ?: return null
        val offset = byteRange.substringAfter('@', "0").toLongOrNull() ?: 0L
        if (length <= 0L) return null
        return "bytes=$offset-${offset + length - 1}"
    }

    private fun concatFiles(initFile: File?, parts: List<File>, output: File) {
        FileOutputStream(output).use { out ->
            if (initFile != null && initFile.exists()) {
                initFile.inputStream().use { it.copyTo(out, 64 * 1024) }
            }
            for (part in parts) {
                if (part.exists()) {
                    part.inputStream().use { it.copyTo(out, 64 * 1024) }
                }
            }
        }
    }

    private suspend fun fetchTextWithRetry(url: String, task: DownloadTask): String {
        return String(fetchBytesWithRetry(url, task, null), Charsets.UTF_8)
    }

    private suspend fun fetchBytesWithRetry(
        url: String,
        task: DownloadTask,
        rangeHeader: String? = null
    ): ByteArray {
        var attempt = 0
        while (true) {
            try {
                val req = OkHttpClientProvider.buildRequest(url, task.headers, extraRange = rangeHeader)
                okHttpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful && resp.code != 206) {
                        if (MultiThreadRangeDownloader.isRetryableHttp(resp.code)) {
                            throw IOException("HTTP ${resp.code}")
                        }
                        throw IllegalStateException("Parça indirilemedi: HTTP ${resp.code}")
                    }
                    return resp.body?.bytes() ?: throw IOException("Boş segment yanıtı")
                }
            } catch (e: Exception) {
                if (!MultiThreadRangeDownloader.isRetryableException(e) || attempt >= MultiThreadRangeDownloader.MAX_RETRIES) {
                    throw e
                }
                attempt++
                delay(MultiThreadRangeDownloader.computeBackoffMs(attempt))
            }
        }
    }
}
