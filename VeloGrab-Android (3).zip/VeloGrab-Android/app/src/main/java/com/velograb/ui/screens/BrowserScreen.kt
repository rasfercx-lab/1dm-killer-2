package com.velograb.ui.screens

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.velograb.domain.model.DetectedStream
import com.velograb.domain.model.DrmStatus
import com.velograb.domain.model.StreamHeaders
import com.velograb.domain.model.StreamVariant
import com.velograb.sniffer.SnifferWebViewClient
import com.velograb.sniffer.StreamJsBridge
import com.velograb.ui.theme.AmoledBackground
import com.velograb.ui.theme.BorderHairline
import com.velograb.ui.theme.CardSurface
import com.velograb.ui.theme.CyanAccent
import com.velograb.ui.theme.ElevatedSurface
import com.velograb.ui.theme.ErrorRed
import com.velograb.ui.theme.SuccessGreen
import com.velograb.ui.theme.TextPrimary
import com.velograb.ui.theme.TextSecondary
import com.velograb.ui.viewmodel.BrowserViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    onNavigateToDownloads: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    BackHandler(enabled = state.canGoBack && !state.isQualitySheetOpen) {
        webViewRef?.goBack()
    }

    val snifferClient = remember(viewModel) {
        SnifferWebViewClient(
            isAdShieldEnabled = { viewModel.uiState.value.isAdShieldEnabled },
            currentUserAgent = {
                if (viewModel.uiState.value.isDesktopMode) StreamHeaders.DEFAULT_DESKTOP_UA
                else StreamHeaders.DEFAULT_MOBILE_UA
            },
            currentPageTitle = { viewModel.uiState.value.pageTitle },
            onPageStartedCallback = { url -> viewModel.onPageStarted(url) },
            onPageFinishedCallback = { url, title ->
                viewModel.onPageFinished(
                    url = url,
                    title = title,
                    canBack = webViewRef?.canGoBack() == true,
                    canForward = webViewRef?.canGoForward() == true
                )
            },
            onAdBlockedCallback = { viewModel.onAdBlocked() },
            onStreamIntercepted = { streamUrl, mimeHint, streamType, pageUrl, pageTitle, headers ->
                viewModel.onStreamDiscovered(
                    url = streamUrl,
                    mimeType = mimeHint,
                    streamType = streamType,
                    pageUrl = pageUrl,
                    pageTitle = pageTitle,
                    headers = headers
                )
            },
            onCandidateStreamIntercepted = { streamUrl, acceptHint, pageUrl, pageTitle, headers ->
                viewModel.onCandidateStreamDiscovered(
                    url = streamUrl,
                    mimeHint = acceptHint,
                    pageUrl = pageUrl,
                    pageTitle = pageTitle,
                    headers = headers
                )
            }
        )
    }

    val jsBridge = remember(viewModel, snifferClient) {
        StreamJsBridge { detectedUrl, mimeHint ->
            val currentState = viewModel.uiState.value
            val ua = if (currentState.isDesktopMode) StreamHeaders.DEFAULT_DESKTOP_UA else StreamHeaders.DEFAULT_MOBILE_UA
            val headers = snifferClient.captureHeaders(
                pageUrl = currentState.currentUrl,
                fallbackUa = ua,
                streamUrl = detectedUrl
            )
            val directType = SnifferWebViewClient.classifyStreamUrl(detectedUrl, mimeHint)
            if (directType != null) {
                viewModel.onStreamDiscovered(
                    url = detectedUrl,
                    mimeType = mimeHint,
                    streamType = directType,
                    pageUrl = currentState.currentUrl,
                    pageTitle = currentState.pageTitle,
                    headers = headers
                )
            } else if (SnifferWebViewClient.isCandidateStreamUrl(detectedUrl, mimeHint)) {
                viewModel.onCandidateStreamDiscovered(
                    url = detectedUrl,
                    mimeHint = mimeHint,
                    pageUrl = currentState.currentUrl,
                    pageTitle = currentState.pageTitle,
                    headers = headers
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Smart Browser Bar
            Surface(
                color = CardSurface,
                tonalElevation = 0.dp,
                border = BorderStroke(1.dp, BorderHairline)
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { webViewRef?.goBack() },
                            enabled = state.canGoBack,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Geri",
                                tint = if (state.canGoBack) TextPrimary else TextSecondary.copy(alpha = 0.35f)
                            )
                        }

                        IconButton(
                            onClick = { webViewRef?.goForward() },
                            enabled = state.canGoForward,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowForward,
                                contentDescription = "İleri",
                                tint = if (state.canGoForward) TextPrimary else TextSecondary.copy(alpha = 0.35f)
                            )
                        }

                        // Address Bar
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .padding(horizontal = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = ElevatedSurface
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                BasicTextField(
                                    value = state.addressInput,
                                    onValueChange = viewModel::onAddressInputChanged,
                                    singleLine = true,
                                    textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp),
                                    cursorBrush = SolidColor(CyanAccent),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                    keyboardActions = KeyboardActions(
                                        onGo = {
                                            focusManager.clearFocus()
                                            val target = viewModel.resolveNavigationUrl(state.addressInput)
                                            webViewRef?.loadUrl(target)
                                        }
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    decorationBox = { innerTextField ->
                                        if (state.addressInput.isEmpty()) {
                                            Text(
                                                "Web adresi girin veya arayın...",
                                                color = TextSecondary,
                                                fontSize = 13.sp,
                                                maxLines = 1
                                            )
                                        }
                                        innerTextField()
                                    }
                                )
                            }
                        }

                        // Refresh
                        IconButton(
                            onClick = { webViewRef?.reload() },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Yenile", tint = TextPrimary)
                        }

                        // Desktop/Mobile UA toggle
                        IconButton(
                            onClick = {
                                viewModel.toggleDesktopMode()
                                webViewRef?.let { wv ->
                                    wv.settings.userAgentString = if (!state.isDesktopMode) {
                                        StreamHeaders.DEFAULT_DESKTOP_UA
                                    } else {
                                        StreamHeaders.DEFAULT_MOBILE_UA
                                    }
                                    wv.reload()
                                }
                            },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = if (state.isDesktopMode) Icons.Rounded.DesktopWindows else Icons.Rounded.PhoneAndroid,
                                contentDescription = "Masaüstü / Mobil Görünüm",
                                tint = if (state.isDesktopMode) CyanAccent else TextSecondary
                            )
                        }

                        // Ad & Popup Shield toggle
                        IconButton(
                            onClick = viewModel::toggleAdShield,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = "Reklam ve Popup Kalkanı",
                                tint = if (state.isAdShieldEnabled) CyanAccent else TextSecondary.copy(alpha = 0.45f)
                            )
                        }
                    }

                    // Shield micro status strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (state.isAdShieldEnabled) {
                                "Reklam & Popup Kalkanı Açık • ${state.blockedAdCount} engellendi"
                            } else {
                                "Reklam & Popup Kalkanı Kapalı"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (state.isAdShieldEnabled) CyanAccent else TextSecondary
                        )
                        Text(
                            text = if (state.isDesktopMode) "Masaüstü Modu" else "Mobil Mod",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    if (state.isLoading) {
                        LinearProgressIndicator(
                            progress = { state.progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.dp),
                            color = CyanAccent,
                            trackColor = ElevatedSurface
                        )
                    }
                }
            }

            // Status Feedback Banner
            state.statusBannerTr?.let { banner ->
                Surface(
                    color = ElevatedSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = banner,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (banner.contains("başlatıldı")) {
                                Text(
                                    text = "Sıraya Git",
                                    color = CyanAccent,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .clickable {
                                            viewModel.clearBanner()
                                            onNavigateToDownloads()
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            IconButton(onClick = viewModel::clearBanner, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Rounded.Close, contentDescription = "Kapat", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Embedded Sniffer WebView
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                factory = { ctx ->
                    @SuppressLint("SetJavaScriptEnabled")
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setSupportMultipleWindows(false)
                            javaScriptCanOpenWindowsAutomatically = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            userAgentString = StreamHeaders.DEFAULT_MOBILE_UA
                        }

                        addJavascriptInterface(jsBridge, StreamJsBridge.BRIDGE_NAME)
                        webViewClient = snifferClient
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                viewModel.onProgressChanged(
                                    progress = newProgress,
                                    canBack = view?.canGoBack() == true,
                                    canForward = view?.canGoForward() == true
                                )
                            }
                        }
                        loadUrl(state.currentUrl)
                        webViewRef = this
                    }
                }
            )
        }

        // Floating Animated Action Pill ("X Video Bulundu • İndir")
        AnimatedVisibility(
            visible = state.detectedStreams.isNotEmpty(),
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 18.dp)
        ) {
            Surface(
                onClick = viewModel::openQualitySheet,
                shape = CircleShape,
                color = CyanAccent,
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = null,
                        tint = AmoledBackground,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "${state.detectedStreams.size} Video Bulundu • İndir",
                        color = AmoledBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }

    // Quality & Variant ModalBottomSheet
    if (state.isQualitySheetOpen) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = viewModel::closeQualitySheet,
            sheetState = sheetState,
            containerColor = CardSurface,
            contentColor = TextPrimary
        ) {
            StreamQualitySheetContent(
                streams = state.detectedStreams,
                customFilename = state.customFilenameInput,
                onCustomFilenameChange = viewModel::onCustomFilenameChanged,
                onSelectVariant = { stream, variant ->
                    viewModel.startDownload(stream, variant, state.customFilenameInput)
                }
            )
        }
    }
}

@Composable
private fun StreamQualitySheetContent(
    streams: List<DetectedStream>,
    customFilename: String,
    onCustomFilenameChange: (String) -> Unit,
    onSelectVariant: (DetectedStream, StreamVariant) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(bottom = 28.dp)
    ) {
        Text(
            text = "Yakalanan Akışlar ve Kaliteler",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Oturum çerezleri ve başlıklar otomatik aktarıldı.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Dosya Adı",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = ElevatedSurface,
            border = BorderStroke(1.dp, BorderHairline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(16.dp)
                )
                Box(modifier = Modifier.weight(1f)) {
                    BasicTextField(
                        value = customFilename,
                        onValueChange = onCustomFilenameChange,
                        singleLine = true,
                        textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp),
                        cursorBrush = SolidColor(CyanAccent),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { innerTextField ->
                            if (customFilename.isEmpty()) {
                                Text(
                                    text = "Özel dosya adı girin (isteğe bağlı)...",
                                    color = TextSecondary,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            innerTextField()
                        }
                    )
                }
                if (customFilename.isNotEmpty()) {
                    IconButton(
                        onClick = { onCustomFilenameChange("") },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Temizle",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            items(streams, key = { it.id }) { stream ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ElevatedSurface,
                    border = BorderStroke(1.dp, BorderHairline)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.VideoLibrary,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = stream.pageTitle,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${stream.streamType.name} • ${stream.url}",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = BorderHairline)
                        Spacer(modifier = Modifier.height(10.dp))

                        when {
                            !stream.isParsed -> {
                                Text("Akış manifesti çözümleniyor...", color = CyanAccent, fontSize = 13.sp)
                            }
                            stream.drmStatus is DrmStatus.Protected -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = stream.drmStatus.message,
                                        color = ErrorRed,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                            stream.parseError != null -> {
                                Text(stream.parseError, color = ErrorRed, fontSize = 13.sp)
                            }
                            stream.variants.isEmpty() -> {
                                Text("Uygun video kalitesi bulunamadı.", color = TextSecondary, fontSize = 13.sp)
                            }
                            else -> {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    stream.variants.forEach { variant ->
                                        Surface(
                                            onClick = { onSelectVariant(stream, variant) },
                                            shape = RoundedCornerShape(12.dp),
                                            color = CardSurface,
                                            border = BorderStroke(1.dp, BorderHairline)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = variant.labelTr,
                                                        fontWeight = FontWeight.SemiBold,
                                                        fontSize = 14.sp,
                                                        color = TextPrimary
                                                    )
                                                    val sizeTxt = variant.estimatedSizeBytes?.let { formatBytesTr(it) } ?: "Boyut akışta"
                                                    Text(
                                                        text = "${variant.codecs} • $sizeTxt",
                                                        fontSize = 12.sp,
                                                        color = if (variant.hasAudio) SuccessGreen else TextSecondary
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(CyanAccent.copy(alpha = 0.16f))
                                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Text(
                                                        text = "İndir",
                                                        color = CyanAccent,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun formatBytesTr(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format(java.util.Locale("tr", "TR"), "%.2f GB", gb)
        mb >= 1.0 -> String.format(java.util.Locale("tr", "TR"), "%.1f MB", mb)
        else -> String.format(java.util.Locale("tr", "TR"), "%.0f KB", kb)
    }
}
