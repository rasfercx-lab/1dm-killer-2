package com.velograb.sniffer

import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.velograb.domain.model.StreamHeaders
import com.velograb.domain.model.StreamType

class SnifferWebViewClient(
    private val isAdShieldEnabled: () -> Boolean,
    private val currentUserAgent: () -> String,
    private val currentPageTitle: () -> String,
    private val onPageStartedCallback: (url: String) -> Unit,
    private val onPageFinishedCallback: (url: String, title: String) -> Unit,
    private val onAdBlockedCallback: (blockedUrl: String) -> Unit,
    private val onStreamIntercepted: (
        streamUrl: String,
        mimeHint: String,
        streamType: StreamType,
        pageUrl: String,
        pageTitle: String,
        headers: StreamHeaders
    ) -> Unit,
    private val onCandidateStreamIntercepted: ((
        streamUrl: String,
        acceptHint: String,
        pageUrl: String,
        pageTitle: String,
        headers: StreamHeaders
    ) -> Unit)? = null
) : WebViewClient() {

    @Volatile
    private var activePageUrl: String = ""

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        if (!url.isNullOrBlank()) {
            activePageUrl = url
            onPageStartedCallback(url)
        }
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        if (!url.isNullOrBlank()) {
            activePageUrl = url
        }
        val title = view?.title?.takeIf { it.isNotBlank() } ?: currentPageTitle()
        onPageFinishedCallback(url.orEmpty(), title)

        // Inject two-layer JS sniffer and optional Popup Shield
        view?.evaluateJavascript(StreamJsBridge.SNIFFER_INJECTION_SCRIPT, null)
        if (isAdShieldEnabled()) {
            view?.evaluateJavascript(AdPopupShield.ANTI_POPUP_SCRIPT, null)
        }
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val url = request?.url?.toString().orEmpty()
        if (url.isBlank()) return false

        if (isAdShieldEnabled() && AdPopupShield.isAdOrRedirectUrl(url)) {
            onAdBlockedCallback(url)
            return true
        }
        return false
    }

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val url = request?.url?.toString().orEmpty()
        if (url.isBlank()) return null

        if (isAdShieldEnabled() && AdPopupShield.isAdOrRedirectUrl(url)) {
            onAdBlockedCallback(url)
            return WebResourceResponse("text/plain", "utf-8", "".byteInputStream())
        }

        val accept = request?.requestHeaders?.let { findHeaderIgnoreCase(it, "Accept") }.orEmpty()
        val detectedType = classifyStreamUrl(url, accept)
        if (detectedType != null) {
            val pageUrl = activePageUrl.ifBlank { url }
            val headers = captureHeaders(
                pageUrl = pageUrl,
                requestHeaders = request?.requestHeaders.orEmpty(),
                fallbackUa = currentUserAgent(),
                streamUrl = url
            )
            onStreamIntercepted(
                url,
                accept,
                detectedType,
                pageUrl,
                currentPageTitle(),
                headers
            )
        } else if (onCandidateStreamIntercepted != null && isCandidateStreamUrl(url, accept)) {
            val pageUrl = activePageUrl.ifBlank { url }
            val headers = captureHeaders(
                pageUrl = pageUrl,
                requestHeaders = request?.requestHeaders.orEmpty(),
                fallbackUa = currentUserAgent(),
                streamUrl = url
            )
            onCandidateStreamIntercepted.invoke(
                url,
                accept,
                pageUrl,
                currentPageTitle(),
                headers
            )
        }

        return super.shouldInterceptRequest(view, request)
    }

    fun captureHeaders(
        pageUrl: String,
        requestHeaders: Map<String, String> = emptyMap(),
        fallbackUa: String = currentUserAgent(),
        streamUrl: String = ""
    ): StreamHeaders {
        val headerReferer = findHeaderIgnoreCase(requestHeaders, "Referer").orEmpty().ifBlank { pageUrl }
        val headerOrigin = findHeaderIgnoreCase(requestHeaders, "Origin").orEmpty().ifBlank {
            deriveOrigin(headerReferer).ifBlank { deriveOrigin(pageUrl) }
        }
        val headerUa = findHeaderIgnoreCase(requestHeaders, "User-Agent").orEmpty().ifBlank { fallbackUa }

        val cookieParts = linkedSetOf<String>()
        findHeaderIgnoreCase(requestHeaders, "Cookie")?.takeIf { it.isNotBlank() }?.let { cookieParts += it }
        listOf(streamUrl, headerReferer, pageUrl)
            .filter { it.isNotBlank() }
            .distinct()
            .forEach { target ->
                runCatching { CookieManager.getInstance().getCookie(target) }
                    .getOrNull()
                    ?.takeIf { it.isNotBlank() }
                    ?.let { cookieParts += it }
            }

        return StreamHeaders(
            userAgent = headerUa,
            referer = headerReferer,
            origin = headerOrigin,
            cookie = mergeCookieStrings(cookieParts)
        )
    }

    private fun findHeaderIgnoreCase(headers: Map<String, String>, key: String): String? {
        headers[key]?.let { return it }
        return headers.entries.firstOrNull { it.key.equals(key, ignoreCase = true) }?.value
    }

    private fun deriveOrigin(url: String): String {
        val parsed = runCatching { Uri.parse(url) }.getOrNull() ?: return ""
        if (parsed.scheme.isNullOrBlank() || parsed.host.isNullOrBlank()) return ""
        val portPart = if (parsed.port != -1 && parsed.port != 80 && parsed.port != 443) {
            ":${parsed.port}"
        } else ""
        return "${parsed.scheme}://${parsed.host}$portPart"
    }

    private fun mergeCookieStrings(cookieHeaders: Iterable<String>): String {
        val map = LinkedHashMap<String, String>()
        for (raw in cookieHeaders) {
            raw.split(';').forEach { part ->
                val trimmed = part.trim()
                val eqIdx = trimmed.indexOf('=')
                if (eqIdx > 0) {
                    val name = trimmed.substring(0, eqIdx).trim()
                    val value = trimmed.substring(eqIdx + 1).trim()
                    if (name.isNotEmpty()) map[name] = value
                }
            }
        }
        return map.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    companion object {
        fun classifyStreamUrl(url: String, mimeOrAcceptHint: String = ""): StreamType? {
            val lowerUrl = url.lowercase()
            val lowerHint = mimeOrAcceptHint.lowercase()
            val pathOnly = lowerUrl.substringBefore('?').substringBefore('#')

            return when {
                pathOnly.endsWith(".m3u8") ||
                    pathOnly.contains(".m3u8/") ||
                    lowerUrl.contains(".m3u8?") ||
                    lowerUrl.contains(".m3u8&") ||
                    lowerHint.contains("application/vnd.apple.mpegurl") ||
                    lowerHint.contains("application/x-mpegurl") -> StreamType.HLS_MASTER

                pathOnly.endsWith(".mpd") ||
                    pathOnly.contains(".mpd/") ||
                    lowerUrl.contains(".mpd?") ||
                    lowerUrl.contains(".mpd&") ||
                    lowerHint.contains("application/dash+xml") -> StreamType.DASH_MPD

                pathOnly.endsWith(".mp4") ||
                    lowerUrl.contains(".mp4?") ||
                    lowerHint.contains("video/mp4") -> StreamType.DIRECT_MP4

                pathOnly.endsWith(".webm") ||
                    lowerUrl.contains(".webm?") ||
                    lowerHint.contains("video/webm") -> StreamType.DIRECT_WEBM

                pathOnly.endsWith(".m4a") ||
                    lowerHint.contains("audio/mp4") -> StreamType.AUDIO_ONLY

                lowerHint.startsWith("video/") -> StreamType.DIRECT_MP4
                else -> null
            }
        }

        private val IGNORED_STATIC_EXTS = listOf(
            ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".webp",
            ".svg", ".woff", ".woff2", ".ttf", ".otf", ".ico", ".map",
            ".vtt", ".srt", ".ts", ".m4s"
        )

        private val IGNORED_TXT_NAMES = listOf(
            "robots.txt", "ads.txt", "app-ads.txt", "security.txt", "humans.txt"
        )

        private val CANDIDATE_PATTERNS = listOf(
            "/hls/", "/master", "/manifest", "/playlist", "/stream/",
            "/vod/", "videoplayback", "mime=video", "mime=audio",
            ".m3u?", ".m3u&", "closeload", "rapidrame"
        )

        fun isCandidateStreamUrl(url: String, acceptOrMimeHint: String = ""): Boolean {
            val trimmed = url.trim()
            if (!trimmed.startsWith("http://", ignoreCase = true) &&
                !trimmed.startsWith("https://", ignoreCase = true)
            ) {
                return false
            }
            if (AdPopupShield.isAdOrRedirectUrl(trimmed)) return false
            if (classifyStreamUrl(trimmed, acceptOrMimeHint) != null) return false

            val lowerUrl = trimmed.lowercase()
            val lowerHint = acceptOrMimeHint.lowercase()
            val pathOnly = lowerUrl.substringBefore('?').substringBefore('#')

            if (IGNORED_STATIC_EXTS.any { pathOnly.endsWith(it) }) return false
            if (IGNORED_TXT_NAMES.any { pathOnly.endsWith("/$it") || pathOnly.endsWith(it) }) return false

            if (pathOnly.endsWith(".m3u") || pathOnly.endsWith(".txt")) return true
            if (lowerHint.contains("mpegurl") || lowerHint.contains("dash+xml")) return true
            if (lowerHint.contains("video/") && !lowerHint.contains("text/html")) return true

            return CANDIDATE_PATTERNS.any { lowerUrl.contains(it) }
        }

        fun detectStreamTypeFromProbe(
            url: String,
            contentType: String?,
            firstBytes: ByteArray
        ): StreamType? {
            val ct = contentType.orEmpty().lowercase()
            if (ct.contains("text/html") || ct.contains("javascript") || ct.contains("text/css") || ct.startsWith("image/")) {
                return null
            }

            val headText = String(firstBytes, Charsets.UTF_8)
                .trimStart('\uFEFF', ' ', '\t', '\r', '\n')

            if (headText.startsWith("<!DOCTYPE", ignoreCase = true) ||
                headText.startsWith("<html", ignoreCase = true)
            ) {
                return null
            }

            return when {
                headText.startsWith("#EXTM3U", ignoreCase = true) ||
                    ct.contains("mpegurl") -> StreamType.HLS_MASTER

                headText.contains("<MPD", ignoreCase = true) ||
                    ct.contains("dash+xml") -> StreamType.DASH_MPD

                firstBytes.size >= 8 &&
                    firstBytes[4] == 'f'.code.toByte() &&
                    firstBytes[5] == 't'.code.toByte() &&
                    firstBytes[6] == 'y'.code.toByte() &&
                    firstBytes[7] == 'p'.code.toByte() -> {
                    if (ct.startsWith("audio/")) StreamType.AUDIO_ONLY else StreamType.DIRECT_MP4
                }

                firstBytes.size >= 4 &&
                    firstBytes[0] == 0x1A.toByte() &&
                    firstBytes[1] == 0x45.toByte() &&
                    firstBytes[2] == 0xDF.toByte() &&
                    firstBytes[3] == 0xA3.toByte() -> StreamType.DIRECT_WEBM

                ct.startsWith("video/webm") -> StreamType.DIRECT_WEBM
                ct.startsWith("video/") -> StreamType.DIRECT_MP4
                ct.startsWith("audio/mp4") || ct.startsWith("audio/aac") || ct.startsWith("audio/mpeg") -> StreamType.AUDIO_ONLY
                else -> classifyStreamUrl(url, ct)
            }
        }
    }
}
