package com.velograb

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.velograb.domain.model.DownloadTask
import com.velograb.download.DownloadForegroundService
import com.velograb.ui.screens.BrowserScreen
import com.velograb.ui.screens.DownloadsScreen
import com.velograb.ui.screens.LibraryScreen
import com.velograb.ui.screens.PlayerScreen
import com.velograb.ui.theme.AmoledBackground
import com.velograb.ui.theme.CardSurface
import com.velograb.ui.theme.CyanAccent
import com.velograb.ui.theme.TextPrimary
import com.velograb.ui.theme.TextSecondary
import com.velograb.ui.theme.VeloGrabTheme
import com.velograb.ui.viewmodel.BrowserViewModel
import com.velograb.ui.viewmodel.DownloadsViewModel
import com.velograb.ui.viewmodel.LibraryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class VeloGrabTab(val labelTr: String) {
    CATCH("Yakala"),
    DOWNLOADS("İndirmeler"),
    LIBRARY("Kütüphane")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VeloGrabTheme {
                VeloGrabRoot()
            }
        }
    }
}

@Composable
private fun VeloGrabRoot() {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(VeloGrabTab.CATCH) }
    var playingVideo by remember { mutableStateOf<DownloadTask?>(null) }

    val browserViewModel: BrowserViewModel = viewModel()
    val downloadsViewModel: DownloadsViewModel = viewModel()
    val libraryViewModel: LibraryViewModel = viewModel()

    // Request POST_NOTIFICATIONS on Android 13+ and WRITE_EXTERNAL_STORAGE on Android <= 9
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    LaunchedEffect(Unit) {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }

        val app = context.applicationContext as VeloGrabApp
        val interruptedTasks = withContext(Dispatchers.IO) {
            app.container.repository.getActiveTasks()
        }
        if (interruptedTasks.isNotEmpty()) {
            DownloadForegroundService.resumeInterruptedIfNeeded(context)
        }
    }

    val currentPlaying = playingVideo
    if (currentPlaying != null && currentPlaying.outputUri != null) {
        PlayerScreen(
            title = currentPlaying.title,
            videoUri = currentPlaying.outputUri,
            onBack = { playingVideo = null }
        )
        return
    }

    Scaffold(
        containerColor = AmoledBackground,
        bottomBar = {
            NavigationBar(containerColor = CardSurface) {
                NavigationBarItem(
                    selected = activeTab == VeloGrabTab.CATCH,
                    onClick = { activeTab = VeloGrabTab.CATCH },
                    icon = { Icon(Icons.Rounded.Explore, contentDescription = null) },
                    label = { Text(VeloGrabTab.CATCH.labelTr) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyanAccent,
                        selectedTextColor = CyanAccent,
                        indicatorColor = CyanAccent.copy(alpha = 0.14f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = activeTab == VeloGrabTab.DOWNLOADS,
                    onClick = { activeTab = VeloGrabTab.DOWNLOADS },
                    icon = { Icon(Icons.Rounded.Download, contentDescription = null) },
                    label = { Text(VeloGrabTab.DOWNLOADS.labelTr) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyanAccent,
                        selectedTextColor = CyanAccent,
                        indicatorColor = CyanAccent.copy(alpha = 0.14f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = activeTab == VeloGrabTab.LIBRARY,
                    onClick = { activeTab = VeloGrabTab.LIBRARY },
                    icon = { Icon(Icons.Rounded.VideoLibrary, contentDescription = null) },
                    label = { Text(VeloGrabTab.LIBRARY.labelTr) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyanAccent,
                        selectedTextColor = CyanAccent,
                        indicatorColor = CyanAccent.copy(alpha = 0.14f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                VeloGrabTab.CATCH -> BrowserScreen(
                    viewModel = browserViewModel,
                    onNavigateToDownloads = { activeTab = VeloGrabTab.DOWNLOADS }
                )
                VeloGrabTab.DOWNLOADS -> DownloadsScreen(viewModel = downloadsViewModel)
                VeloGrabTab.LIBRARY -> LibraryScreen(
                    viewModel = libraryViewModel,
                    onPlayVideo = { task -> playingVideo = task }
                )
            }
        }
    }
}
