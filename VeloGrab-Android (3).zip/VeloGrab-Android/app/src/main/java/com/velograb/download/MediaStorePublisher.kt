package com.velograb.download

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.IOException

object MediaStorePublisher {

    suspend fun publishToMoviesVeloGrab(
        context: Context,
        sourceFile: File,
        displayName: String,
        mimeType: String = "video/mp4",
        isAudioOnly: Boolean = false
    ): Uri = withContext(Dispatchers.IO) {
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            throw IOException("Yayınlanacak medya dosyası boş veya bulunamadı.")
        }

        val ext = when {
            isAudioOnly -> ".m4a"
            mimeType.equals("video/webm", ignoreCase = true) -> ".webm"
            else -> ".mp4"
        }
        val sanitizedName = sanitizeFileName(displayName, ext)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val collection = if (isAudioOnly) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }

            val relativeDir = if (isAudioOnly) {
                "${Environment.DIRECTORY_MUSIC}/VeloGrab"
            } else {
                "${Environment.DIRECTORY_MOVIES}/VeloGrab"
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, sanitizedName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeDir)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val resolver = context.contentResolver
            val itemUri = resolver.insert(collection, values)
                ?: throw IOException("MediaStore kaydı oluşturulamadı.")

            try {
                resolver.openOutputStream(itemUri)?.use { out ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(out, bufferSize = 64 * 1024)
                    }
                } ?: throw IOException("Medya çıkış akışı açılamadı.")

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                itemUri
            } catch (e: Exception) {
                resolver.delete(itemUri, null, null)
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val baseDir = Environment.getExternalStoragePublicDirectory(
                if (isAudioOnly) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            )
            val veloDir = File(baseDir, "VeloGrab").apply { mkdirs() }
            val destFile = resolveUniqueFile(veloDir, sanitizedName)
            sourceFile.copyTo(destFile, overwrite = true)

            MediaScannerConnection.scanFile(
                context,
                arrayOf(destFile.absolutePath),
                arrayOf(mimeType),
                null
            )
            Uri.fromFile(destFile)
        }
    }

    private fun sanitizeFileName(name: String, extension: String): String {
        val base = name
            .replace(Regex("""[\\/:*?"<>|]"""), "_")
            .trim()
            .ifBlank { "VeloGrab_Video_${System.currentTimeMillis()}" }
            .take(80)
        return if (base.endsWith(extension, ignoreCase = true)) base else "$base$extension"
    }

    private fun resolveUniqueFile(dir: File, fileName: String): File {
        var candidate = File(dir, fileName)
        if (!candidate.exists()) return candidate
        val stem = fileName.substringBeforeLast('.')
        val ext = fileName.substringAfterLast('.', "mp4")
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "${stem}_$counter.$ext")
            counter++
        }
        return candidate
    }
}
