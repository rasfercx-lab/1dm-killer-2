package com.velograb.sniffer

import android.webkit.JavascriptInterface

class StreamJsBridge(
    private val onStreamDiscovered: (url: String, mimeHint: String) -> Unit
) {

    @JavascriptInterface
    fun onMediaDetected(url: String?, mimeHint: String?) {
        val cleanUrl = url?.trim().orEmpty()
        if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
            onStreamDiscovered(cleanUrl, mimeHint?.trim().orEmpty())
        }
    }

    companion object {
        const val BRIDGE_NAME = "VeloGrabBridge"

        val SNIFFER_INJECTION_SCRIPT = """
            (function() {
                if (window.__velograbSnifferInstalled) return;
                window.__velograbSnifferInstalled = true;

                var mediaPattern = /\.(m3u8|mpd|mp4|webm|m4a|m4s)(\?|#|${'$'}|&)/i;
                var candidatePattern = /(\/hls\/|\/manifest|\/master|\/playlist|\/stream|\/vod\/|videoplayback|mime=video|\.m3u(\?|#|${'$'}|&)|\.txt(\?|#|${'$'}|&)|closeload|rapidrame)/i;
                var skipTextPattern = /\.(js|css|svg|png|jpg|jpeg|webp|woff2?|ttf|ico)(\?|#|${'$'}|&)/i;

                function report(url, hint, allowCandidate) {
                    if (!url || typeof url !== 'string') return;
                    if (url.startsWith('blob:') || url.startsWith('data:')) return;
                    if (mediaPattern.test(url) || (hint && /mpegurl|dash\+xml|video\//i.test(hint))) {
                        try {
                            window.VeloGrabBridge.onMediaDetected(url, hint || '');
                        } catch (_) {}
                        return;
                    }
                    if (allowCandidate && !skipTextPattern.test(url) && candidatePattern.test(url)) {
                        try {
                            window.VeloGrabBridge.onMediaDetected(url, hint || 'candidate');
                        } catch (_) {}
                    }
                }

                function inspectManifestSnippet(url, text, fallbackHint) {
                    if (!text || typeof text !== 'string') return;
                    var head = text.slice(0, 1024).trim();
                    if (/^#EXTM3U/i.test(head)) {
                        report(url, 'application/vnd.apple.mpegurl', false);
                    } else if (/<MPD[\s>]/i.test(head)) {
                        report(url, 'application/dash+xml', false);
                    } else if (fallbackHint) {
                        report(url, fallbackHint, true);
                    }
                }

                function scanDomMedia() {
                    var videos = document.querySelectorAll('video, source');
                    for (var i = 0; i < videos.length; i++) {
                        var el = videos[i];
                        var src = el.currentSrc || el.src || el.getAttribute('src');
                        if (src) report(src, el.type || 'video/mp4', true);
                    }
                }

                // Hook HTMLMediaElement.play & load
                var origPlay = HTMLMediaElement.prototype.play;
                HTMLMediaElement.prototype.play = function() {
                    scanDomMedia();
                    if (this.currentSrc || this.src) {
                        report(this.currentSrc || this.src, 'video/mp4', true);
                    }
                    return origPlay.apply(this, arguments);
                };

                var origLoad = HTMLMediaElement.prototype.load;
                HTMLMediaElement.prototype.load = function() {
                    scanDomMedia();
                    if (this.currentSrc || this.src) {
                        report(this.currentSrc || this.src, 'video/mp4', true);
                    }
                    return origLoad.apply(this, arguments);
                };

                // Hook fetch() with non-destructive small-payload manifest peek
                var origFetch = window.fetch;
                if (origFetch) {
                    window.fetch = function(input, init) {
                        var reqUrl = typeof input === 'string' ? input : (input && input.url ? input.url : '');
                        report(reqUrl, '', true);
                        return origFetch.apply(this, arguments).then(function(resp) {
                            try {
                                var finalUrl = resp.url || reqUrl;
                                var ct = resp.headers && resp.headers.get ? (resp.headers.get('content-type') || '') : '';
                                var cl = Number(resp.headers && resp.headers.get ? (resp.headers.get('content-length') || '0') : '0');
                                report(finalUrl, ct, true);
                                if (resp.clone && (!cl || cl <= 524288) && (!ct || /text|mpegurl|dash|json|octet-stream/i.test(ct)) && !skipTextPattern.test(finalUrl)) {
                                    resp.clone().text().then(function(txt) {
                                        inspectManifestSnippet(finalUrl, txt, ct);
                                    }).catch(function() {});
                                }
                            } catch (_) {}
                            return resp;
                        });
                    };
                }

                // Hook XMLHttpRequest.open & response text manifest peek
                var origXhrOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function(method, url) {
                    this.__vgUrl = url;
                    report(url, '', true);
                    this.addEventListener('load', function() {
                        try {
                            var finalUrl = this.responseURL || this.__vgUrl;
                            var ct = this.getResponseHeader('content-type') || '';
                            report(finalUrl, ct, true);
                            if ((!this.responseType || this.responseType === 'text') && typeof this.responseText === 'string' && this.responseText.length > 0 && this.responseText.length <= 524288) {
                                inspectManifestSnippet(finalUrl, this.responseText, ct);
                            }
                        } catch (_) {}
                    });
                    return origXhrOpen.apply(this, arguments);
                };

                // Observe dynamic DOM additions & src attribute changes
                if (typeof MutationObserver !== 'undefined') {
                    var obs = new MutationObserver(function() { scanDomMedia(); });
                    obs.observe(document.documentElement || document, {
                        childList: true,
                        subtree: true,
                        attributes: true,
                        attributeFilter: ['src']
                    });
                }

                scanDomMedia();
            })();
        """.trimIndent()
    }
}
