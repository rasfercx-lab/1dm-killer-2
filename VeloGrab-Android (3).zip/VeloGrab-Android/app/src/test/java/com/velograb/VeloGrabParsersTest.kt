package com.velograb

import com.velograb.domain.model.DrmStatus
import com.velograb.domain.model.StreamType
import com.velograb.parser.DrmGuard
import com.velograb.parser.HlsPlaylistParser
import com.velograb.sniffer.AdPopupShield
import com.velograb.sniffer.SnifferWebViewClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VeloGrabParsersTest {

    @Test
    fun `hls master playlist pairs video variants with separate audio rendition`() {
        val master = """
            #EXTM3U
            #EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aac",NAME="Turkish",DEFAULT=YES,URI="audio/aac.m3u8"
            #EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080,CODECS="avc1.640028,mp4a.40.2",AUDIO="aac"
            video/1080p.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720,CODECS="avc1.4d401f,mp4a.40.2",AUDIO="aac"
            video/720p.m3u8
        """.trimIndent()

        val result = HlsPlaylistParser.parse(master, "https://cdn.example.com/stream/master.m3u8")
        assertTrue(result.isMaster)
        assertTrue(result.drmStatus is DrmStatus.Clear)
        assertEquals(3, result.variants.size) // 1080p + 720p + audio-only
        assertEquals("1080p Full HD (Sesli)", result.variants[0].labelTr)
        assertEquals("https://cdn.example.com/stream/audio/aac.m3u8", result.variants[0].audioUrl)
        assertEquals(StreamType.HLS_AUDIO, result.variants[2].streamType)
    }

    @Test
    fun `hls media playlist resolves implicit byterange offsets cleanly`() {
        val playlist = """
            #EXTM3U
            #EXT-X-MAP:URI="init.mp4",BYTERANGE="720@0"
            #EXTINF:4.0,
            #EXT-X-BYTERANGE:1000@720
            main.mp4
            #EXTINF:4.0,
            #EXT-X-BYTERANGE:1500
            main.mp4
        """.trimIndent()

        val parsed = HlsPlaylistParser.parseMediaPlaylist(playlist, "https://cdn.example.com/hls/v.m3u8")
        assertEquals(2, parsed.segments.size)
        assertEquals("720@0", parsed.segments[0].initByteRange)
        assertEquals("1000@720", parsed.segments[0].byteRange)
        assertEquals("1500@1720", parsed.segments[1].byteRange)
    }

    @Test
    fun `drm guard blocks widevine and sample-aes streams`() {
        val drmManifest = """
            #EXTM3U
            #EXT-X-KEY:METHOD=SAMPLE-AES,URI="skd://key.example.com/123"
            #EXTINF:6.0,
            seg1.ts
        """.trimIndent()

        val status = DrmGuard.inspectHlsManifest(drmManifest)
        assertTrue(status is DrmStatus.Protected)
        assertEquals(DrmGuard.DRM_MESSAGE_TR, (status as DrmStatus.Protected).message)
    }

    @Test
    fun `ad shield detects ad domains and intent redirects`() {
        assertTrue(AdPopupShield.isAdOrRedirectUrl("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"))
        assertTrue(AdPopupShield.isAdOrRedirectUrl("intent://play.google.com/store/apps"))
        assertFalse(AdPopupShield.isAdOrRedirectUrl("https://cdn.example.com/video/1080p.m3u8"))
    }

    @Test
    fun `sniffer classifies hls dash and mp4 accurately`() {
        assertEquals(StreamType.HLS_MASTER, SnifferWebViewClient.classifyStreamUrl("https://vod.test/master.m3u8?token=1"))
        assertEquals(StreamType.DASH_MPD, SnifferWebViewClient.classifyStreamUrl("https://vod.test/manifest.mpd"))
        assertEquals(StreamType.DIRECT_MP4, SnifferWebViewClient.classifyStreamUrl("https://vod.test/clip.mp4"))
        assertNotNull(SnifferWebViewClient.classifyStreamUrl("https://vod.test/stream", "application/vnd.apple.mpegurl"))
    }

    @Test
    fun `sniffer identifies extensionless close rapidrame candidates and verifies 512-byte magic headers`() {
        assertTrue(SnifferWebViewClient.isCandidateStreamUrl("https://closeload.top/hls/abc123?t=999"))
        assertTrue(SnifferWebViewClient.isCandidateStreamUrl("https://cdn.rapidrame.net/playlist/token.txt"))
        assertFalse(SnifferWebViewClient.isCandidateStreamUrl("https://cdn.example.com/robots.txt"))
        assertFalse(SnifferWebViewClient.isCandidateStreamUrl("https://cdn.example.com/seg_001.ts"))

        assertEquals(
            StreamType.HLS_MASTER,
            SnifferWebViewClient.detectStreamTypeFromProbe(
                url = "https://closeload.top/stream/xyz",
                contentType = "text/plain",
                firstBytes = "#EXTM3U\n#EXT-X-VERSION:3".toByteArray()
            )
        )
        assertEquals(
            StreamType.DIRECT_MP4,
            SnifferWebViewClient.detectStreamTypeFromProbe(
                url = "https://cdn.rapidrame.net/v/123",
                contentType = "application/octet-stream",
                firstBytes = byteArrayOf(0x00, 0x00, 0x00, 0x18, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte())
            )
        )
        assertEquals(
            null,
            SnifferWebViewClient.detectStreamTypeFromProbe(
                url = "https://closeload.top/embed/abc",
                contentType = "text/html; charset=utf-8",
                firstBytes = "<!DOCTYPE html><html></html>".toByteArray()
            )
        )
    }
}
