package com.velograb.parser

import com.velograb.domain.model.DrmStatus

object DrmGuard {

    const val DRM_MESSAGE_TR = "Bu içerik DRM korumalı olduğu için indirilemez."

    private const val WIDEVINE_UUID = "edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"
    private const val PLAYREADY_UUID = "9a04f079-9840-4286-ab92-e65be0885f95"
    private const val FAIRPLAY_SCHEME = "skd://"

    fun inspectHlsManifest(manifestText: String): DrmStatus {
        val lower = manifestText.lowercase()
        return when {
            lower.contains(WIDEVINE_UUID) || lower.contains("com.widevine") ->
                DrmStatus.Protected("Widevine DRM", DRM_MESSAGE_TR)

            lower.contains(PLAYREADY_UUID) || lower.contains("com.microsoft.playready") ->
                DrmStatus.Protected("PlayReady DRM", DRM_MESSAGE_TR)

            lower.contains(FAIRPLAY_SCHEME) || lower.contains("com.apple.streamingkeydelivery") ->
                DrmStatus.Protected("FairPlay DRM", DRM_MESSAGE_TR)

            lower.contains("method=sample-aes") || lower.contains("method=sample-aes-ctr") ->
                DrmStatus.Protected("SAMPLE-AES DRM", DRM_MESSAGE_TR)

            else -> DrmStatus.Clear
        }
    }

    fun inspectDashContentProtection(schemeIdUri: String?, value: String?): DrmStatus {
        val combined = "${schemeIdUri.orEmpty()} ${value.orEmpty()}".lowercase()
        return when {
            combined.contains(WIDEVINE_UUID) || combined.contains("widevine") ->
                DrmStatus.Protected("Widevine DRM", DRM_MESSAGE_TR)

            combined.contains(PLAYREADY_UUID) || combined.contains("playready") ->
                DrmStatus.Protected("PlayReady DRM", DRM_MESSAGE_TR)

            combined.contains("fairplay") ->
                DrmStatus.Protected("FairPlay DRM", DRM_MESSAGE_TR)

            combined.contains("cenc") || combined.contains("mp4protection") ->
                DrmStatus.Protected("CENC DRM", DRM_MESSAGE_TR)

            else -> DrmStatus.Clear
        }
    }
}
