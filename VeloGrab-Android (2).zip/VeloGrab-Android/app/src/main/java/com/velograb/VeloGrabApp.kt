package com.velograb

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.velograb.data.local.DownloadDatabase
import com.velograb.data.repository.DownloadRepository
import com.velograb.network.OkHttpClientProvider
import okhttp3.OkHttpClient

class AppContainer(context: Context) {
    val okHttpClient: OkHttpClient = OkHttpClientProvider.client
    private val database: DownloadDatabase = DownloadDatabase.build(context)
    val repository: DownloadRepository = DownloadRepository(database.downloadDao())
}

class VeloGrabApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_DOWNLOADS,
                getString(R.string.notification_channel_downloads),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_downloads_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "velograb_downloads"
    }
}
