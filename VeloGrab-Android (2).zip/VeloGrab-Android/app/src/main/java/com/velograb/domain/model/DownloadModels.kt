package com.velograb.domain.model

enum class DownloadStatus {
    QUEUED,
    PROBING,
    DOWNLOADING,
    MUXING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class DownloadTask(
    val id: String,
    val title: String,
    val sourceDomain: String,
    val pageUrl: String,
    val videoUrl: String,
    val audioUrl: String?,
    val streamType: StreamType,
    val qualityLabel: String,
    val headers: StreamHeaders,
    val status: DownloadStatus,
    val progressPercent: Float,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val etaSeconds: Long,
    val completedSegments: Int,
    val totalSegments: Int,
    val outputUri: String?,
    val fileName: String,
    val durationMs: Long,
    val errorMessage: String?,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

data class ChunkRange(
    val index: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long,
    val isCompleted: Boolean
)
