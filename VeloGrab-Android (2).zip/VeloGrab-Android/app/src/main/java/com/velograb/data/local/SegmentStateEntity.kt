package com.velograb.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "segment_states",
    primaryKeys = ["downloadId", "trackKind", "segmentIndex"],
    foreignKeys = [
        ForeignKey(
            entity = DownloadEntity::class,
            parentColumns = ["id"],
            childColumns = ["downloadId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("downloadId")]
)
data class SegmentStateEntity(
    val downloadId: String,
    val trackKind: String, // "video" or "audio"
    val segmentIndex: Int,
    val byteSize: Long,
    val isCompleted: Boolean
)
