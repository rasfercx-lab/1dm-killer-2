package com.velograb.sniffer

import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.velograb.domain.model.StreamHeaders
import com.velograb.domain.model.StreamType

class SnifferWebViewClient(
    private val isAdShieldEnabled: () -> Boolean,
    private val currentUserAgent: () -> String,
    private val currentPageTitle: () -> String,
    private val onPageStartedCallback: (url: String) -> Unit,
    private val onPageFinishedCallback: (url: String, title: String) -> Unit,
    private val onAdBlockedCallback: (blockedUrl: String) -> Unit,
    private val onStreamIntercepted: (
        streamUrl: String,
        mimeHint: String,
        streamType: StreamType,
        pageUrl: String,
        pageTitle: String,
        headers: StreamHeaders
    ) -> Unit
) : WebViewClient() {

    @Volatile
    private var activePageUrl: String = ""

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        if (!url.isNullOrBlank()) {
            activePageUrl = url
            onPageStartedCallback(url)
        }
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        if (!url.isNullOrBlank()) {
            activePageUrl = url
        }
        val title = view?.title?.takeIf { it.isNotBlank() } ?: currentPageTitle()
        onPageFinishedCallback(url.orEmpty(), title)

        // Inject two-layer JS sniffer and optional Popup Shield
        view?.evaluateJavascript(StreamJsBridge.SNIFFER_INJECTION_SCRIPT, null)
        if (isAdShieldEnabled()) {
            view?.evaluateJavascript(AdPopupShield.ANTI_POPUP_SCRIPT, null)
        }
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val url = request?.url?.toString().orEmpty()
        if (url.isBlank()) return false

        if (isAdShieldEnabled() && AdPopupShield.isAdOrRedirectUrl(url)) {
            onAdBlockedCallback(url)
            return true
        }
        return false
    }

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val url = request?.url?.toString().orEmpty()
        if (url.isBlank()) return null

        if (isAdShieldEnabled() && AdPopupShield.isAdOrRedirectUrl(url)) {
            onAdBlockedCallback(url)
            return WebResourceResponse("text/plain", "utf-8", "".byteInputStream())
        }

        val accept = request?.requestHeaders?.get("Accept") ?: ""
        val detectedType = classifyStreamUrl(url, accept)
        if (detectedType != null) {
            val pageUrl = activePageUrl.ifBlank { url }
            val headers = captureHeaders(
                pageUrl = pageUrl,
                requestHeaders = request?.requestHeaders.orEmpty(),
                fallbackUa = currentUserAgent()
            )
            onStreamIntercepted(
                url,
                accept,
                detectedType,
                pageUrl,
                currentPageTitle(),
                headers
            )
        }

        return super.shouldInterceptRequest(view, request)
    }

    fun captureHeaders(
        pageUrl: String,
        requestHeaders: Map<String, String> = emptyMap(),
        fallbackUa: String = currentUserAgent()
    ): StreamHeaders {
        val cookie = runCatching { CookieManager.getInstance().getCookie(pageUrl) }.getOrNull().orEmpty()
        val parsedPage = runCatching { Uri.parse(pageUrl) }.getOrNull()
        val origin = if (parsedPage != null && !parsedPage.scheme.isNullOrBlank() && !parsedPage.host.isNullOrBlank()) {
            val portPart = if (parsedPage.port != -1 && parsedPage.port != 80 && parsedPage.port != 443) {
                ":${parsedPage.port}"
            } else ""
            "${parsedPage.scheme}://${parsedPage.host}$portPart"
        } else ""

        return StreamHeaders(
            userAgent = requestHeaders["User-Agent"] ?: fallbackUa,
            referer = requestHeaders["Referer"] ?: pageUrl,
            origin = requestHeaders["Origin"] ?: origin,
            cookie = requestHeaders["Cookie"] ?: cookie
        )
    }

    companion object {
        fun classifyStreamUrl(url: String, mimeOrAcceptHint: String = ""): StreamType? {
            val lowerUrl = url.lowercase()
            val lowerHint = mimeOrAcceptHint.lowercase()
            val pathOnly = lowerUrl.substringBefore('?').substringBefore('#')

            return when {
                pathOnly.endsWith(".m3u8") ||
                    lowerUrl.contains(".m3u8?") ||
                    lowerHint.contains("application/vnd.apple.mpegurl") ||
                    lowerHint.contains("application/x-mpegurl") -> StreamType.HLS_MASTER

                pathOnly.endsWith(".mpd") ||
                    lowerUrl.contains(".mpd?") ||
                    lowerHint.contains("application/dash+xml") -> StreamType.DASH_MPD

                pathOnly.endsWith(".mp4") ||
                    lowerUrl.contains(".mp4?") ||
                    lowerHint.contains("video/mp4") -> StreamType.DIRECT_MP4

                pathOnly.endsWith(".webm") ||
                    lowerUrl.contains(".webm?") ||
                    lowerHint.contains("video/webm") -> StreamType.DIRECT_WEBM

                pathOnly.endsWith(".m4a") ||
                    lowerHint.contains("audio/mp4") -> StreamType.AUDIO_ONLY

                lowerHint.startsWith("video/") -> StreamType.DIRECT_MP4
                else -> null
            }
        }
    }
}
