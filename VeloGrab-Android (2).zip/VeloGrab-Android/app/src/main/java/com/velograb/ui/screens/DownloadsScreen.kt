package com.velograb.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.ui.theme.AmoledBackground
import com.velograb.ui.theme.BorderHairline
import com.velograb.ui.theme.CardSurface
import com.velograb.ui.theme.CyanAccent
import com.velograb.ui.theme.ElevatedSurface
import com.velograb.ui.theme.ErrorRed
import com.velograb.ui.theme.SuccessGreen
import com.velograb.ui.theme.TextPrimary
import com.velograb.ui.theme.TextSecondary
import com.velograb.ui.theme.WarningAmber
import com.velograb.ui.viewmodel.DownloadsViewModel
import java.util.Locale

@Composable
fun DownloadsScreen(viewModel: DownloadsViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "İndirmeler",
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
        Text(
            text = "4 paralel bağlantılı kopmasız indirme motoru",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (state.activeDownloads.isEmpty() && state.pastDownloads.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.DownloadDone,
                        contentDescription = null,
                        tint = CyanAccent.copy(alpha = 0.65f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Henüz aktif indirme yok",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Yakala sekmesinden bir video açıp oynatarak indirebilirsiniz.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                if (state.activeDownloads.isNotEmpty()) {
                    item {
                        Text(
                            text = "Etkin Sıra (${state.activeDownloads.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanAccent
                        )
                    }
                    items(state.activeDownloads, key = { it.id }) { task ->
                        ActiveDownloadCard(
                            task = task,
                            onPause = { viewModel.pauseDownload(task.id) },
                            onResume = { viewModel.resumeDownload(task.id) },
                            onRetry = { viewModel.retryDownload(task.id) },
                            onCancel = { viewModel.cancelDownload(task.id) }
                        )
                    }
                }

                if (state.pastDownloads.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Geçmiş (${state.pastDownloads.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                    items(state.pastDownloads, key = { it.id }) { task ->
                        HistoryDownloadCard(
                            task = task,
                            onRemove = { viewModel.removeFromHistory(task.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveDownloadCard(
    task: DownloadTask,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRetry: () -> Unit,
    onCancel: () -> Unit
) {
    val animatedProgress by animateFloatAsState(
        targetValue = (task.progressPercent / 100f).coerceIn(0f, 1f),
        label = "download_progress"
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardSurface,
        border = BorderStroke(1.dp, BorderHairline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${task.sourceDomain} • ${task.qualityLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (task.status) {
                        DownloadStatus.DOWNLOADING, DownloadStatus.PROBING, DownloadStatus.QUEUED -> {
                            IconButton(onClick = onPause) {
                                Icon(Icons.Rounded.Pause, contentDescription = "Duraklat", tint = CyanAccent)
                            }
                        }
                        DownloadStatus.PAUSED -> {
                            IconButton(onClick = onResume) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Devam Et", tint = CyanAccent)
                            }
                        }
                        DownloadStatus.FAILED -> {
                            IconButton(onClick = onRetry) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "Yeniden Dene", tint = WarningAmber)
                            }
                        }
                        DownloadStatus.MUXING -> Unit
                        else -> Unit
                    }
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Rounded.Close, contentDescription = "İptal Et", tint = TextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (task.status == DownloadStatus.FAILED) ErrorRed else CyanAccent,
                trackColor = ElevatedSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val statusLabel = when (task.status) {
                    DownloadStatus.QUEUED -> "Sırada..."
                    DownloadStatus.PROBING -> "Sunucu kontrol ediliyor..."
                    DownloadStatus.DOWNLOADING -> formatSpeedTr(task.speedBytesPerSec)
                    DownloadStatus.MUXING -> "Ses ve görüntü birleştiriliyor..."
                    DownloadStatus.PAUSED -> "Duraklatıldı"
                    DownloadStatus.FAILED -> task.errorMessage ?: "Bağlantı hatası"
                    else -> ""
                }
                Text(
                    text = statusLabel,
                    fontSize = 12.sp,
                    color = if (task.status == DownloadStatus.FAILED) ErrorRed else CyanAccent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                val sizeProgress = if (task.totalBytes > 0) {
                    "${formatBytesTr(task.downloadedBytes)} / ${formatBytesTr(task.totalBytes)}"
                } else {
                    formatBytesTr(task.downloadedBytes)
                }
                val etaText = if (task.status == DownloadStatus.DOWNLOADING && task.etaSeconds > 0) {
                    " • ${formatEtaTr(task.etaSeconds)}"
                } else ""
                Text(
                    text = "$sizeProgress$etaText",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun HistoryDownloadCard(
    task: DownloadTask,
    onRemove: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = CardSurface,
        border = BorderStroke(1.dp, BorderHairline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val statusStr = if (task.status == DownloadStatus.COMPLETED) {
                    "Tamamlandı • ${formatBytesTr(task.totalBytes)}"
                } else {
                    "İptal Edildi"
                }
                Text(
                    text = "${task.sourceDomain} • $statusStr",
                    fontSize = 12.sp,
                    color = if (task.status == DownloadStatus.COMPLETED) SuccessGreen else TextSecondary
                )
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Listeden Kaldır", tint = TextSecondary)
            }
        }
    }
}

fun formatSpeedTr(bytesPerSec: Long): String {
    if (bytesPerSec <= 0L) return "0 KB/sn"
    val kb = bytesPerSec / 1024.0
    return if (kb >= 1024.0) {
        String.format(Locale("tr", "TR"), "%.1f MB/sn", kb / 1024.0)
    } else {
        String.format(Locale("tr", "TR"), "%.0f KB/sn", kb)
    }
}

fun formatEtaTr(seconds: Long): String {
    return when {
        seconds < 60 -> "${seconds}sn kaldı"
        seconds < 3600 -> "${seconds / 60}dk ${seconds % 60}sn"
        else -> "${seconds / 3600}sa ${(seconds % 3600) / 60}dk"
    }
}
