package com.velograb.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.velograb.VeloGrabApp
import com.velograb.domain.model.DetectedStream
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.domain.model.DrmStatus
import com.velograb.domain.model.StreamHeaders
import com.velograb.domain.model.StreamType
import com.velograb.domain.model.StreamVariant
import com.velograb.download.DownloadForegroundService
import com.velograb.network.OkHttpClientProvider
import com.velograb.parser.DashMpdParser
import com.velograb.parser.HlsPlaylistParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class BrowserUiState(
    val addressInput: String = "https://duckduckgo.com",
    val currentUrl: String = "https://duckduckgo.com",
    val pageTitle: String = "Yeni Sekme",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isAdShieldEnabled: Boolean = true,
    val blockedAdCount: Int = 0,
    val isDesktopMode: Boolean = false,
    val detectedStreams: List<DetectedStream> = emptyList(),
    val isQualitySheetOpen: Boolean = false,
    val statusBannerTr: String? = null
)

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as VeloGrabApp
    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    private val seenUrls = ConcurrentHashMap.newKeySet<String>()

    fun onAddressInputChanged(value: String) {
        _uiState.update { it.copy(addressInput = value) }
    }

    fun resolveNavigationUrl(rawInput: String): String {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return _uiState.value.currentUrl

        val looksLikeUrl = trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) ||
            (!trimmed.contains(' ') && trimmed.contains('.'))

        val resolved = when {
            trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true) -> trimmed
            looksLikeUrl -> "https://$trimmed"
            else -> "https://duckduckgo.com/?q=${URLEncoder.encode(trimmed, "UTF-8")}"
        }
        _uiState.update { it.copy(addressInput = resolved) }
        return resolved
    }

    fun onPageStarted(url: String) {
        seenUrls.clear()
        _uiState.update {
            it.copy(
                currentUrl = url,
                addressInput = url,
                isLoading = true,
                detectedStreams = emptyList(),
                statusBannerTr = null
            )
        }
    }

    fun onPageFinished(url: String, title: String, canBack: Boolean, canForward: Boolean) {
        _uiState.update {
            it.copy(
                currentUrl = url.ifBlank { it.currentUrl },
                pageTitle = title.ifBlank { it.pageTitle },
                isLoading = false,
                progress = 100,
                canGoBack = canBack,
                canGoForward = canForward
            )
        }
    }

    fun onProgressChanged(progress: Int, canBack: Boolean, canForward: Boolean) {
        _uiState.update {
            it.copy(
                progress = progress,
                isLoading = progress < 100,
                canGoBack = canBack,
                canGoForward = canForward
            )
        }
    }

    fun toggleAdShield() {
        _uiState.update { it.copy(isAdShieldEnabled = !it.isAdShieldEnabled) }
    }

    fun toggleDesktopMode() {
        _uiState.update { it.copy(isDesktopMode = !it.isDesktopMode) }
    }

    fun onAdBlocked() {
        _uiState.update { it.copy(blockedAdCount = it.blockedAdCount + 1) }
    }

    fun openQualitySheet() {
        _uiState.update { it.copy(isQualitySheetOpen = true) }
    }

    fun closeQualitySheet() {
        _uiState.update { it.copy(isQualitySheetOpen = false) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(statusBannerTr = null) }
    }

    fun onStreamDiscovered(
        url: String,
        mimeType: String,
        streamType: StreamType,
        pageUrl: String,
        pageTitle: String,
        headers: StreamHeaders
    ) {
        if (!seenUrls.add(url)) return

        val streamId = UUID.randomUUID().toString()
        val initialStream = DetectedStream(
            id = streamId,
            url = url,
            pageTitle = pageTitle.ifBlank { "Yakalanan Video" },
            pageUrl = pageUrl,
            mimeType = mimeType,
            streamType = streamType,
            headers = headers,
            isParsed = false
        )

        _uiState.update { state ->
            state.copy(detectedStreams = listOf(initialStream) + state.detectedStreams)
        }

        viewModelScope.launch {
            inspectStreamMetadata(initialStream)
        }
    }

    private suspend fun inspectStreamMetadata(stream: DetectedStream) = withContext(Dispatchers.IO) {
        try {
            when (stream.streamType) {
                StreamType.HLS_MASTER, StreamType.HLS_MEDIA, StreamType.HLS_AUDIO -> {
                    val req = OkHttpClientProvider.buildRequest(stream.url, stream.headers)
                    app.container.okHttpClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) {
                            updateStreamError(stream.id, "Akış listesi alınamadı (HTTP ${resp.code})")
                            return@withContext
                        }
                        val bodyText = resp.body?.string().orEmpty()
                        val parsed = HlsPlaylistParser.parse(bodyText, stream.url)
                        updateStreamParsed(stream.id, parsed.drmStatus, parsed.variants, null)
                    }
                }

                StreamType.DASH_MPD, StreamType.DASH_AUDIO -> {
                    val req = OkHttpClientProvider.buildRequest(stream.url, stream.headers)
                    app.container.okHttpClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) {
                            updateStreamError(stream.id, "DASH manifesti alınamadı (HTTP ${resp.code})")
                            return@withContext
                        }
                        val xml = resp.body?.string().orEmpty()
                        val (drmStatus, variants) = DashMpdParser.parseToVariants(xml, stream.url)
                        updateStreamParsed(stream.id, drmStatus, variants, null)
                    }
                }

                StreamType.DIRECT_MP4, StreamType.DIRECT_WEBM, StreamType.AUDIO_ONLY -> {
                    val headReq = OkHttpClientProvider.buildRequest(stream.url, stream.headers)
                        .newBuilder().head().build()
                    val size = runCatching {
                        app.container.okHttpClient.newCall(headReq).execute().use { r ->
                            r.header("Content-Length")?.toLongOrNull()
                        }
                    }.getOrNull()

                    val label = if (stream.streamType == StreamType.AUDIO_ONLY) {
                        "Doğrudan Ses (M4A)"
                    } else {
                        "Doğrudan Video (${if (stream.streamType == StreamType.DIRECT_WEBM) "WebM" else "MP4"})"
                    }

                    val directVariant = StreamVariant(
                        id = "direct_${stream.id}",
                        labelTr = label,
                        resolution = "Orijinal",
                        height = 1080,
                        bandwidthBps = 0L,
                        codecs = if (stream.streamType == StreamType.DIRECT_WEBM) "VP9 / Opus" else "MP4 (H.264/AAC)",
                        hasAudio = true,
                        isAudioOnly = stream.streamType == StreamType.AUDIO_ONLY,
                        videoUrl = stream.url,
                        audioUrl = null,
                        streamType = stream.streamType,
                        estimatedSizeBytes = size,
                        drmStatus = DrmStatus.Clear
                    )
                    updateStreamParsed(stream.id, DrmStatus.Clear, listOf(directVariant), size)
                }
            }
        } catch (e: Exception) {
            updateStreamError(stream.id, e.localizedMessage ?: "Akış incelenemedi.")
        }
    }

    private fun updateStreamParsed(
        streamId: String,
        drmStatus: DrmStatus,
        variants: List<StreamVariant>,
        contentLength: Long?
    ) {
        _uiState.update { state ->
            state.copy(
                detectedStreams = state.detectedStreams.map { item ->
                    if (item.id == streamId) {
                        item.copy(
                            isParsed = true,
                            drmStatus = drmStatus,
                            variants = variants,
                            contentLengthBytes = contentLength ?: item.contentLengthBytes
                        )
                    } else item
                }
            )
        }
    }

    private fun updateStreamError(streamId: String, error: String) {
        _uiState.update { state ->
            state.copy(
                detectedStreams = state.detectedStreams.map { item ->
                    if (item.id == streamId) item.copy(isParsed = true, parseError = error) else item
                }
            )
        }
    }

    fun startDownload(stream: DetectedStream, variant: StreamVariant) {
        if (variant.drmStatus is DrmStatus.Protected) {
            _uiState.update { it.copy(statusBannerTr = variant.drmStatus.message) }
            return
        }

        viewModelScope.launch {
            val taskId = UUID.randomUUID().toString()
            val domain = runCatching { Uri.parse(stream.pageUrl).host.orEmpty() }.getOrDefault("")
                .ifBlank { runCatching { Uri.parse(variant.videoUrl).host.orEmpty() }.getOrDefault("web") }

            val now = System.currentTimeMillis()
            val cleanTitle = stream.pageTitle
                .replace(" - YouTube", "")
                .trim()
                .ifBlank { "Video_${now % 10000}" }

            val ext = if (variant.isAudioOnly) "m4a" else if (variant.streamType == StreamType.DIRECT_WEBM) "webm" else "mp4"
            val task = DownloadTask(
                id = taskId,
                title = cleanTitle,
                sourceDomain = domain,
                pageUrl = stream.pageUrl,
                videoUrl = variant.videoUrl,
                audioUrl = variant.audioUrl,
                streamType = variant.streamType,
                qualityLabel = variant.labelTr,
                headers = stream.headers,
                status = DownloadStatus.QUEUED,
                progressPercent = 0f,
                downloadedBytes = 0L,
                totalBytes = variant.estimatedSizeBytes ?: 0L,
                speedBytesPerSec = 0L,
                etaSeconds = 0L,
                completedSegments = 0,
                totalSegments = 0,
                outputUri = null,
                fileName = "${cleanTitle.take(40)}.$ext",
                durationMs = 0L,
                errorMessage = null,
                createdAtMillis = now,
                updatedAtMillis = now
            )

            app.container.repository.insertOrUpdate(task)
            DownloadForegroundService.sendCommand(
                context = app,
                action = DownloadForegroundService.ACTION_START,
                taskId = taskId
            )
            _uiState.update {
                it.copy(
                    isQualitySheetOpen = false,
                    statusBannerTr = "İndirme başlatıldı: ${variant.labelTr}"
                )
            }
        }
    }
}
