package com.velograb.data.repository

import com.velograb.data.local.ChunkStateEntity
import com.velograb.data.local.DownloadDao
import com.velograb.data.local.DownloadEntity
import com.velograb.data.local.SegmentStateEntity
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DownloadRepository(
    private val dao: DownloadDao
) {
    fun observeAllDownloads(): Flow<List<DownloadTask>> =
        dao.observeAll().map { entities -> entities.map { it.toDomain() } }

    fun observeCompletedLibrary(): Flow<List<DownloadTask>> =
        dao.observeCompleted().map { entities -> entities.map { it.toDomain() } }

    suspend fun getTask(id: String): DownloadTask? =
        dao.getById(id)?.toDomain()

    suspend fun insertOrUpdate(task: DownloadTask) {
        dao.upsert(DownloadEntity.fromDomain(task))
    }

    suspend fun updateProgress(
        id: String,
        status: DownloadStatus,
        progressPercent: Float,
        downloadedBytes: Long,
        totalBytes: Long,
        speedBytesPerSec: Long,
        etaSeconds: Long,
        completedSegments: Int = 0,
        totalSegments: Int = 0,
        errorMessage: String? = null
    ) {
        dao.updateProgress(
            id = id,
            status = status.name,
            progressPercent = progressPercent.coerceIn(0f, 100f),
            downloadedBytes = downloadedBytes,
            totalBytes = totalBytes,
            speedBytesPerSec = speedBytesPerSec,
            etaSeconds = etaSeconds,
            completedSegments = completedSegments,
            totalSegments = totalSegments,
            errorMessage = errorMessage,
            updatedAtMillis = System.currentTimeMillis()
        )
    }

    suspend fun markCompleted(
        id: String,
        outputUri: String,
        finalBytes: Long,
        durationMs: Long
    ) {
        dao.markCompleted(
            id = id,
            status = DownloadStatus.COMPLETED.name,
            outputUri = outputUri,
            finalBytes = finalBytes,
            durationMs = durationMs,
            updatedAtMillis = System.currentTimeMillis()
        )
    }

    suspend fun updateStatus(
        id: String,
        status: DownloadStatus,
        errorMessage: String? = null
    ) {
        dao.updateStatus(
            id = id,
            status = status.name,
            errorMessage = errorMessage,
            updatedAtMillis = System.currentTimeMillis()
        )
    }

    suspend fun deleteTask(id: String) {
        dao.deleteById(id)
    }

    suspend fun getChunks(downloadId: String): List<ChunkStateEntity> =
        dao.getChunks(downloadId)

    suspend fun saveChunks(chunks: List<ChunkStateEntity>) {
        dao.upsertChunks(chunks)
    }

    suspend fun updateChunkProgress(
        downloadId: String,
        chunkIndex: Int,
        downloadedBytes: Long,
        isCompleted: Boolean
    ) {
        dao.updateChunkProgress(downloadId, chunkIndex, downloadedBytes, isCompleted)
    }

    suspend fun getCompletedSegments(downloadId: String, trackKind: String): Map<Int, SegmentStateEntity> =
        dao.getCompletedSegments(downloadId, trackKind)
            .filter { it.isCompleted }
            .associateBy { it.segmentIndex }

    suspend fun markSegmentCompleted(
        downloadId: String,
        trackKind: String,
        segmentIndex: Int,
        byteSize: Long
    ) {
        dao.upsertSegment(
            SegmentStateEntity(
                downloadId = downloadId,
                trackKind = trackKind,
                segmentIndex = segmentIndex,
                byteSize = byteSize,
                isCompleted = true
            )
        )
    }
}
