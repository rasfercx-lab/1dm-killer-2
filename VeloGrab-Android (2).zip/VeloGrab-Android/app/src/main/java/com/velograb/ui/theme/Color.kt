package com.velograb.ui.theme

import androidx.compose.ui.graphics.Color

val AmoledBackground = Color(0xFF090D16)
val CardSurface = Color(0xFF121A2B)
val ElevatedSurface = Color(0xFF1A253D)
val CyanAccent = Color(0xFF06B6D4)
val CyanAccentPressed = Color(0xFF0891B2)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val BorderHairline = Color(0xFF1E293B)
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
