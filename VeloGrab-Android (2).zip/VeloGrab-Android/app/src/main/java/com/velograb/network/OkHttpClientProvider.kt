package com.velograb.network

import com.velograb.domain.model.StreamHeaders
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object OkHttpClientProvider {

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectionPool(ConnectionPool(12, 5, TimeUnit.MINUTES))
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    fun buildRequest(
        url: String,
        headers: StreamHeaders,
        extraRange: String? = null
    ): Request {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", headers.userAgent.ifBlank { StreamHeaders.DEFAULT_MOBILE_UA })
            .header("Accept", "*/*")

        if (headers.referer.isNotBlank()) builder.header("Referer", headers.referer)
        if (headers.origin.isNotBlank()) builder.header("Origin", headers.origin)
        if (headers.cookie.isNotBlank()) builder.header("Cookie", headers.cookie)
        if (!extraRange.isNullOrBlank()) builder.header("Range", extraRange)

        return builder.build()
    }
}
