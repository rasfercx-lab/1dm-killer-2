package com.velograb.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.velograb.VeloGrabApp
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.download.DownloadForegroundService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DownloadsUiState(
    val activeDownloads: List<DownloadTask> = emptyList(),
    val pastDownloads: List<DownloadTask> = emptyList()
)

class DownloadsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as VeloGrabApp
    private val repository = app.container.repository

    val uiState: StateFlow<DownloadsUiState> = repository.observeAllDownloads()
        .map { tasks ->
            DownloadsUiState(
                activeDownloads = tasks.filter {
                    it.status != DownloadStatus.COMPLETED && it.status != DownloadStatus.CANCELLED
                },
                pastDownloads = tasks.filter {
                    it.status == DownloadStatus.COMPLETED || it.status == DownloadStatus.CANCELLED
                }
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = DownloadsUiState()
        )

    fun pauseDownload(taskId: String) {
        DownloadForegroundService.sendCommand(app, DownloadForegroundService.ACTION_PAUSE, taskId)
    }

    fun resumeDownload(taskId: String) {
        DownloadForegroundService.sendCommand(app, DownloadForegroundService.ACTION_RESUME, taskId)
    }

    fun retryDownload(taskId: String) {
        DownloadForegroundService.sendCommand(app, DownloadForegroundService.ACTION_START, taskId)
    }

    fun cancelDownload(taskId: String) {
        DownloadForegroundService.sendCommand(app, DownloadForegroundService.ACTION_CANCEL, taskId)
    }

    fun removeFromHistory(taskId: String) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
        }
    }
}
