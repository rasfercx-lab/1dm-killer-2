package com.velograb.sniffer

import android.webkit.JavascriptInterface

class StreamJsBridge(
    private val onStreamDiscovered: (url: String, mimeHint: String) -> Unit
) {

    @JavascriptInterface
    fun onMediaDetected(url: String?, mimeHint: String?) {
        val cleanUrl = url?.trim().orEmpty()
        if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
            onStreamDiscovered(cleanUrl, mimeHint?.trim().orEmpty())
        }
    }

    companion object {
        const val BRIDGE_NAME = "VeloGrabBridge"

        val SNIFFER_INJECTION_SCRIPT = """
            (function() {
                if (window.__velograbSnifferInstalled) return;
                window.__velograbSnifferInstalled = true;

                var mediaPattern = /\.(m3u8|mpd|mp4|webm|m4s)(\?|#|${'$'}|&)/i;

                function report(url, hint) {
                    if (!url || typeof url !== 'string') return;
                    if (url.startsWith('blob:') || url.startsWith('data:')) return;
                    if (mediaPattern.test(url) || (hint && /mpegurl|dash\+xml|video\//i.test(hint))) {
                        try {
                            window.VeloGrabBridge.onMediaDetected(url, hint || '');
                        } catch (_) {}
                    }
                }

                function scanDomMedia() {
                    var videos = document.querySelectorAll('video, source');
                    for (var i = 0; i < videos.length; i++) {
                        var el = videos[i];
                        var src = el.currentSrc || el.src || el.getAttribute('src');
                        if (src) report(src, el.type || 'video/mp4');
                    }
                }

                // Hook HTMLMediaElement.play
                var origPlay = HTMLMediaElement.prototype.play;
                HTMLMediaElement.prototype.play = function() {
                    scanDomMedia();
                    if (this.currentSrc || this.src) {
                        report(this.currentSrc || this.src, 'video/mp4');
                    }
                    return origPlay.apply(this, arguments);
                };

                // Hook fetch()
                var origFetch = window.fetch;
                if (origFetch) {
                    window.fetch = function(input, init) {
                        var reqUrl = typeof input === 'string' ? input : (input && input.url ? input.url : '');
                        report(reqUrl, '');
                        return origFetch.apply(this, arguments).then(function(resp) {
                            try {
                                var ct = resp.headers && resp.headers.get ? (resp.headers.get('content-type') || '') : '';
                                report(resp.url || reqUrl, ct);
                            } catch (_) {}
                            return resp;
                        });
                    };
                }

                // Hook XMLHttpRequest.open & response
                var origXhrOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function(method, url) {
                    this.__vgUrl = url;
                    report(url, '');
                    this.addEventListener('load', function() {
                        try {
                            var ct = this.getResponseHeader('content-type') || '';
                            report(this.responseURL || this.__vgUrl, ct);
                        } catch (_) {}
                    });
                    return origXhrOpen.apply(this, arguments);
                };

                // Observe dynamic DOM additions
                if (typeof MutationObserver !== 'undefined') {
                    var obs = new MutationObserver(function() { scanDomMedia(); });
                    obs.observe(document.documentElement || document, { childList: true, subtree: true });
                }

                scanDomMedia();
            })();
        """.trimIndent()
    }
}
