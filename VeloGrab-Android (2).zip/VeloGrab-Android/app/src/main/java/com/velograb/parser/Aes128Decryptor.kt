package com.velograb.parser

import com.velograb.domain.model.HlsKeyInfo
import com.velograb.domain.model.StreamHeaders
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class Aes128Decryptor(
    private val okHttpClient: OkHttpClient
) {
    private val keyCache = ConcurrentHashMap<String, ByteArray>()

    fun decryptIfNeeded(
        bytes: ByteArray,
        keyInfo: HlsKeyInfo?,
        segmentSequenceIndex: Int,
        headers: StreamHeaders
    ): ByteArray {
        if (keyInfo == null || !keyInfo.method.equals("AES-128", ignoreCase = true)) {
            return bytes
        }
        val keyUri = keyInfo.uri ?: throw IOException("AES-128 anahtar adresi bulunamadı.")
        val keyBytes = keyCache[keyUri] ?: fetchKey(keyUri, headers).also {
            keyCache[keyUri] = it
        }
        val ivBytes = buildIvBytes(keyInfo.ivHex, segmentSequenceIndex)

        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(ivBytes))
        return cipher.doFinal(bytes)
    }

    private fun fetchKey(keyUri: String, headers: StreamHeaders): ByteArray {
        val reqBuilder = Request.Builder()
            .url(keyUri)
            .header("User-Agent", headers.userAgent)
        if (headers.referer.isNotBlank()) reqBuilder.header("Referer", headers.referer)
        if (headers.origin.isNotBlank()) reqBuilder.header("Origin", headers.origin)
        if (headers.cookie.isNotBlank()) reqBuilder.header("Cookie", headers.cookie)

        okHttpClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("Şifre çözme anahtarı alınamadı: HTTP ${resp.code}")
            }
            val raw = resp.body?.bytes() ?: throw IOException("Boş AES-128 anahtarı.")
            if (raw.size != 16) {
                throw IOException("Geçersiz AES-128 anahtar boyutu: ${raw.size} bayt")
            }
            return raw
        }
    }

    private fun buildIvBytes(ivHex: String?, sequenceIndex: Int): ByteArray {
        if (!ivHex.isNullOrBlank()) {
            val clean = ivHex.removePrefix("0x").removePrefix("0X").padStart(32, '0')
            return ByteArray(16) { idx ->
                clean.substring(idx * 2, idx * 2 + 2).toInt(16).toByte()
            }
        }
        val buffer = ByteBuffer.allocate(16)
        buffer.putLong(0L)
        buffer.putLong(sequenceIndex.toLong())
        return buffer.array()
    }
}
