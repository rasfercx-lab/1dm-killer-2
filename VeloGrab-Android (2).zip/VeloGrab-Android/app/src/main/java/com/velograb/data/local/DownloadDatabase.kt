package com.velograb.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        DownloadEntity::class,
        ChunkStateEntity::class,
        SegmentStateEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DownloadDatabase : RoomDatabase() {
    abstract fun downloadDao(): DownloadDao

    companion object {
        fun build(context: Context): DownloadDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                DownloadDatabase::class.java,
                "velograb_downloads.db"
            ).fallbackToDestructiveMigration().build()
        }
    }
}
