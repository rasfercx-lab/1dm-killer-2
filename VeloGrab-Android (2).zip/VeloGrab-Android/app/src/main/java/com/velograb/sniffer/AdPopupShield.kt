package com.velograb.sniffer

import android.net.Uri

object AdPopupShield {

    private val blockedHosts = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "exoclick.com",
        "juicyads.com",
        "trafficjunky.net",
        "adsterra.com",
        "adcash.com",
        "onclickads.net",
        "hilltopads.net",
        "mgid.com",
        "taboola.com",
        "outbrain.com",
        "revcontent.com",
        "yandex.ru",
        "mc.yandex.ru"
    )

    private val blockedUrlFragments = listOf(
        "/popunder",
        "/popup",
        "adclick.",
        "pagead/",
        "doubleclick",
        "clickadu",
        "bet365",
        "1xbet",
        "/banner_ads/",
        "vast.xml",
        "vpaid"
    )

    fun isAdOrRedirectUrl(url: String): Boolean {
        val normalized = url.lowercase().trim()
        if (normalized.startsWith("intent://") ||
            normalized.startsWith("market://") ||
            normalized.startsWith("mailto:") ||
            normalized.startsWith("tel:")
        ) {
            return true
        }
        val host = runCatching { Uri.parse(normalized).host.orEmpty() }.getOrDefault("")
        if (blockedHosts.any { blocked -> host == blocked || host.endsWith(".$blocked") }) {
            return true
        }
        return blockedUrlFragments.any { fragment -> normalized.contains(fragment) }
    }

    const val ANTI_POPUP_SCRIPT = """
        (function() {
            if (window.__velograbShieldInstalled) return;
            window.__velograbShieldInstalled = true;
            window.open = function() { return null; };
            document.addEventListener('click', function(e) {
                var a = e.target && e.target.closest ? e.target.closest('a') : null;
                if (a && a.getAttribute('target') === '_blank') {
                    var href = a.href || '';
                    if (/doubleclick|popads|popcash|exoclick|adsterra|clickadu|propeller/i.test(href)) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                }
            }, true);
        })();
    """
}
