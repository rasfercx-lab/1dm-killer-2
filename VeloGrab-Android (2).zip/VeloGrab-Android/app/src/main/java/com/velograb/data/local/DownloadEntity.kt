package com.velograb.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.domain.model.StreamHeaders
import com.velograb.domain.model.StreamType

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sourceDomain: String,
    val pageUrl: String,
    val videoUrl: String,
    val audioUrl: String?,
    val streamType: String,
    val qualityLabel: String,
    val headersJson: String,
    val status: String,
    val progressPercent: Float,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val etaSeconds: Long,
    val completedSegments: Int,
    val totalSegments: Int,
    val outputUri: String?,
    val fileName: String,
    val durationMs: Long,
    val errorMessage: String?,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain(): DownloadTask = DownloadTask(
        id = id,
        title = title,
        sourceDomain = sourceDomain,
        pageUrl = pageUrl,
        videoUrl = videoUrl,
        audioUrl = audioUrl,
        streamType = runCatching { StreamType.valueOf(streamType) }.getOrDefault(StreamType.DIRECT_MP4),
        qualityLabel = qualityLabel,
        headers = StreamHeaders.fromJson(headersJson),
        status = runCatching { DownloadStatus.valueOf(status) }.getOrDefault(DownloadStatus.QUEUED),
        progressPercent = progressPercent,
        downloadedBytes = downloadedBytes,
        totalBytes = totalBytes,
        speedBytesPerSec = speedBytesPerSec,
        etaSeconds = etaSeconds,
        completedSegments = completedSegments,
        totalSegments = totalSegments,
        outputUri = outputUri,
        fileName = fileName,
        durationMs = durationMs,
        errorMessage = errorMessage,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    companion object {
        fun fromDomain(task: DownloadTask): DownloadEntity = DownloadEntity(
            id = task.id,
            title = task.title,
            sourceDomain = task.sourceDomain,
            pageUrl = task.pageUrl,
            videoUrl = task.videoUrl,
            audioUrl = task.audioUrl,
            streamType = task.streamType.name,
            qualityLabel = task.qualityLabel,
            headersJson = task.headers.toJson(),
            status = task.status.name,
            progressPercent = task.progressPercent,
            downloadedBytes = task.downloadedBytes,
            totalBytes = task.totalBytes,
            speedBytesPerSec = task.speedBytesPerSec,
            etaSeconds = task.etaSeconds,
            completedSegments = task.completedSegments,
            totalSegments = task.totalSegments,
            outputUri = task.outputUri,
            fileName = task.fileName,
            durationMs = task.durationMs,
            errorMessage = task.errorMessage,
            createdAtMillis = task.createdAtMillis,
            updatedAtMillis = task.updatedAtMillis
        )
    }
}
