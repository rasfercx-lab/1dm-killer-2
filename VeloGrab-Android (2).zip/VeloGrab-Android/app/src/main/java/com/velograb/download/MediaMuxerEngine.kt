package com.velograb.download

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object MediaMuxerEngine {

    data class MuxResult(
        val outputFile: File,
        val durationMs: Long
    )

    suspend fun muxToMp4(
        context: Context,
        videoInput: File?,
        audioInput: File?,
        outputFile: File
    ): MuxResult = withContext(Dispatchers.IO) {
        if (videoInput == null && audioInput == null) {
            throw IllegalArgumentException("Birleştirilecek medya dosyası bulunamadı.")
        }
        if (outputFile.exists()) outputFile.delete()
        outputFile.parentFile?.mkdirs()

        // Fast lossless MediaExtractor + MediaMuxer path (works natively for MP4/fMP4/AAC/H.264)
        val fastSuccess = runCatching {
            muxWithPlatformMediaMuxer(videoInput, audioInput, outputFile)
        }.isSuccess

        if (!fastSuccess || !outputFile.exists() || outputFile.length() == 0L) {
            if (outputFile.exists()) outputFile.delete()
            // Fallback to Media3 Transformer (handles MPEG-TS / heterogeneous streams seamlessly)
            muxWithMedia3Transformer(context, videoInput, audioInput, outputFile)
        }

        val durationMs = extractDurationMs(outputFile)
        MuxResult(outputFile = outputFile, durationMs = durationMs)
    }

    private fun muxWithPlatformMediaMuxer(
        videoFile: File?,
        audioFile: File?,
        outputFile: File
    ) {
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val videoExtractor = if (videoFile != null && videoFile.exists()) MediaExtractor() else null
        val audioExtractor = if (audioFile != null && audioFile.exists()) MediaExtractor() else null

        try {
            var outVideoTrack = -1
            var inVideoTrack = -1
            var embeddedAudioTrack = -1
            var outEmbeddedAudioTrack = -1

            if (videoExtractor != null && videoFile != null) {
                videoExtractor.setDataSource(videoFile.absolutePath)
                for (i in 0 until videoExtractor.trackCount) {
                    val format = videoExtractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                    if (mime.startsWith("video/") && inVideoTrack == -1) {
                        inVideoTrack = i
                        outVideoTrack = muxer.addTrack(format)
                    } else if (audioExtractor == null && mime.startsWith("audio/") && embeddedAudioTrack == -1) {
                        embeddedAudioTrack = i
                        outEmbeddedAudioTrack = muxer.addTrack(format)
                    }
                }
            }

            var inExternalAudioTrack = -1
            var outExternalAudioTrack = -1
            if (audioExtractor != null && audioFile != null) {
                audioExtractor.setDataSource(audioFile.absolutePath)
                for (i in 0 until audioExtractor.trackCount) {
                    val format = audioExtractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                    if (mime.startsWith("audio/") && inExternalAudioTrack == -1) {
                        inExternalAudioTrack = i
                        outExternalAudioTrack = muxer.addTrack(format)
                    }
                }
            }

            if (outVideoTrack == -1 && outExternalAudioTrack == -1 && outEmbeddedAudioTrack == -1) {
                throw IllegalStateException("Birleştirilecek geçerli ses/görüntü izi bulunamadı.")
            }

            muxer.start()

            if (videoExtractor != null && inVideoTrack != -1) {
                copyTrackSamples(videoExtractor, inVideoTrack, muxer, outVideoTrack)
            }
            if (videoExtractor != null && embeddedAudioTrack != -1 && outEmbeddedAudioTrack != -1) {
                copyTrackSamples(videoExtractor, embeddedAudioTrack, muxer, outEmbeddedAudioTrack)
            }
            if (audioExtractor != null && inExternalAudioTrack != -1 && outExternalAudioTrack != -1) {
                copyTrackSamples(audioExtractor, inExternalAudioTrack, muxer, outExternalAudioTrack)
            }

            muxer.stop()
        } finally {
            runCatching { videoExtractor?.release() }
            runCatching { audioExtractor?.release() }
            runCatching { muxer.release() }
        }
    }

    private fun copyTrackSamples(
        extractor: MediaExtractor,
        sourceTrackIndex: Int,
        muxer: MediaMuxer,
        destTrackIndex: Int
    ) {
        extractor.selectTrack(sourceTrackIndex)
        extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        val bufferSize = 1024 * 1024 // 1 MB sample buffer
        val buffer = ByteBuffer.allocate(bufferSize)
        val info = MediaCodec.BufferInfo()
        var lastPts = -1L

        while (true) {
            info.offset = 0
            val sampleSize = extractor.readSampleData(buffer, 0)
            if (sampleSize < 0) break

            val sampleTime = extractor.sampleTime
            if (sampleTime >= 0 && sampleTime >= lastPts) {
                info.size = sampleSize
                info.presentationTimeUs = sampleTime
                @Suppress("DEPRECATION")
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(destTrackIndex, buffer, info)
                lastPts = sampleTime
            }
            if (!extractor.advance()) break
        }
        extractor.unselectTrack(sourceTrackIndex)
    }

    @OptIn(UnstableApi::class)
    private suspend fun muxWithMedia3Transformer(
        context: Context,
        videoFile: File?,
        audioFile: File?,
        outputFile: File
    ) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { cont ->
            val sequences = mutableListOf<EditedMediaItemSequence>()
            if (videoFile != null && videoFile.exists()) {
                val videoEdited = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(videoFile))).build()
                sequences += EditedMediaItemSequence(listOf(videoEdited))
            }
            if (audioFile != null && audioFile.exists()) {
                val audioEdited = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(audioFile))).build()
                sequences += EditedMediaItemSequence(listOf(audioEdited))
            }

            val composition = Composition.Builder(sequences).build()
            val transformer = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                })
                .build()

            transformer.start(composition, outputFile.absolutePath)
            cont.invokeOnCancellation {
                transformer.cancel()
            }
        }
    }

    fun extractDurationMs(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }
}
